        <!-- maintenance.php -->
<?php include_once('js/analysis.js');?>
            <h1>Einstellungen</h1>
            <div id="Tabs" style="margin-left: 10px;">
                <ul>
                    <li class="active" id="li_tab1" onclick="tab('tab1')"><a>Allgmein</a></li>
                    <li id="li_tab2" onclick="tab('tab2')"><a>Test</a></li>
                </ul>
                <div class="content">
                    <div class="content_box">
                        <div id="tab1">
                        </div>
                        <div id="tab2" style="display: none;">
                            <div class="tab_container">
<!--
							<div class="mode_header">
									<span>Konstant</span>
								</div>
								<div class="mode_content">
									<div>
										<span class="setting_name">Soll-Temperatur</span>
										<input type="text" name="targetTemp" class="setting_editbox">
										<div class="setting_explanation">Voreingestellte Temperatur, die die gegebene Dauer gehalten werden soll.</div>
									</div>
									<div style="margin-top: 50px;">
										<span class="setting_name">Dauer</span>
										<input type="text" name="targetTemp" class="setting_editbox">
										<div class="setting_explanation">Dauer in Minuten, die die vorgegebenen Temperatur gehalten werden soll.</div>
									</div>
								</div>
-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                function tab(tab) {
                    document.getElementById('tab1').style.display = 'none';
                    document.getElementById('tab2').style.display = 'none';
                    document.getElementById('li_tab1').setAttribute("class", "");
                    document.getElementById('li_tab2').setAttribute("class", "");
                    document.getElementById(tab).style.display = 'block';
                    document.getElementById('li_'+tab).setAttribute("class", "active");
                }
            </script>
        <!-- maintenance.php --> 
