<?php
    $site_title     = "FermPi - Fermentation Controller";
    $site_charset   = "utf-8";

    define('DB_SERVER', "homenet");       	                                 // Server
    define('DB_NAME', "fermpi");            	                                 // Database
    define('DB_USER', "fermpi");                                                 // Username
    define('DB_PASSWORD', "frosttau97");                                         // Password

    define('PDO_DB_DSN', 'mysql:host=homenet;dbname=fermpi;charset=utf8');       // Data Source Name (DSN)
    define('PDO_DB_USER', 'fermpi');                                             // Benutzername
    define('PDO_DB_PWD', 'frosttau97');                                              // Passwort
?>
