<?php
	function debug_to_console( $data ) {
		
		$output = '';
		
		if( is_array( $data ) ) {
            $output .= "console.warn( 'Debug Objects with Array.' ); console.log( '" . preg_replace("/\n/", "\\n", str_replace("'", "\'", var_export($data, TRUE))) . "' );";
		} 
        else if( is_object( $data ) ) {
			$data    = var_export( $data, TRUE );
			$data    = explode( "\n", $data );
			foreach( $data as $line ) {
				if( trim( $line ) ) {
					$line    = addslashes( $line );
					$output .= "console.log( '{$line}' );";
				}
			}
			$output = "<script>console.warn( 'Debug Objects with Object.' ); $output</script>";
		} 
        else {
			$output .= "<script>console.log( 'Debug Objects: {$data}' );</script>";
		}
		
		echo $output;
	}
        
    function delLastChar( $string="" )
    {
        $t = substr($string, 0, -1);
        return($t);
    }

    function utcTimestamp() {
		
		$state  = 0;
		$mode   = 0;
		$log    = 0;
		$ts_utc = '0';
		
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
		
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
			// check state
            $sql = "SELECT * FROM config WHERE item = 'state'";
            if ($result = $mysqli->query($sql)) {
				if ($row = $result->fetch_array()) {
					$state = $row['value'];
				}
			}
			
			if ($state == 1) {
				//check mode
				$sql = "SELECT * FROM config WHERE item = 'mode'";
				if ($result = $mysqli->query($sql)) {
					if ($row = $result->fetch_array()) {
						$mode = $row['value'];
					}
				}
				
				switch ($mode) {
					case 0:
						$log = 0;
						break;					
					default:
						$sql = "SELECT * FROM config WHERE item = 'log'";
						if ($result = $mysqli->query($sql)) {
							if ($row = $result->fetch_array()) {
								$log = $row['value'];
							}
						}
				}
				
				$sql = "SELECT timestamp
						  FROM logs
						 WHERE fermentation = '".$log."'
						   AND sensor = '1'
						 ORDER BY timestamp DESC
						 LIMIT 1";
				
				if ($result = $mysqli->query($sql)) {
					if ($row = $result->fetch_array()) {
						$ts_utc = $row['timestamp'];
					}
				}
			}
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            $error = "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
		
		return $ts_utc;
    }

	function getStatus() {
		$error        = '';
		$status       = '';
		$mode         = '';
		$log          = '';
		$fermentation = '';
		$sensor_1     = '';
		$sensor_2     = '';
		$target       = '';
		$ts_utc       = '0';
		$ts_local     = '0';
		
		$a = array();
		
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT item, value FROM config WHERE 1"; 
            if ($result = $mysqli->query($sql)) {
                while( $data = $result->fetch_array() ) {
                    switch( $data['item'] ) {
                        case 'state':
                            $status  = $data['value'];
                            break;
                        case 'mode':
                            $mode   = $data['value'];
                            break;
                        case 'log':
                            $log    = $data['value'];
                            break;
                        case 'target':
                        default:
                            // unknown config column
                    }
                }
                $result->free();
            }

            if( $status == 1 ) {
                $sql = "SELECT name FROM fermentations WHERE id = '".$log."'";
                if ($result = $mysqli->query($sql)) { 
                    if( ($row = $result->fetch_array()) ) {
                        $fermentation = $row['name'];
                    }
                    $result->free();
                }

                $sql = "SELECT *
                        FROM logs
                        WHERE fermentation = '".$log."'
                        ORDER BY timestamp DESC
                        LIMIT 1";
                if ($result = $mysqli->query($sql)) { 
                    if( ($row = $result->fetch_array()) ) {
                        $ts_utc   = $row['timestamp'];
                        $ts_local = $ts_utc + date('Z');
                    }
                    $result->free();

                    $sql = "SELECT *
                            FROM logs
                            WHERE fermentation = '".$log."'
                            AND timestamp = '".$ts_utc."'";
                    
                    if ($result = $mysqli->query($sql)) { 
                        while( $row = $result->fetch_array() ) {
                            switch( $row['sensor'] ) {
                                case '0':
                                    $target   = $row['temperature'];
                                    break;
                                case '1':
                                    $sensor_1 = $row['temperature'];
                                    break;
                                case '2':
                                    $sensor_2 = $row['temperature'];
                                    break;
                            }
                        }
                    }
                }
            }
          
            // close connection
            $mysqli->close();

			$a['status']       = $status;
			$a['mode']         = $mode;
			$a['log']          = $log;
			$a['fermentation'] = $fermentation;
			$a['s1']           = $sensor_1;
			$a['s2']           = $sensor_2;
			$a['target']       = $target;
        }
        else {
			$a['error'] = $mysqli->connect_error;
        }
		
		return $a;
	}

    function getTemperatureChartValues( $sensor ) {
		
		$state  = 0;
		$mode   = 0;
		$log    = 0;
        $values = '';
		
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
        
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
			// check state
            $sql = "SELECT * FROM config WHERE item = 'state'";
            if ($result = $mysqli->query($sql)) {
				if ($row = $result->fetch_array()) {
					$state = $row['value'];
				}
			}
			
			if ($state == 1) {
				//check mode
				$sql = "SELECT * FROM config WHERE item = 'mode'";
				if ($result = $mysqli->query($sql)) {
					if ($row = $result->fetch_array()) {
						$mode = $row['value'];
					}
				}

				switch ($mode) {
					case 0:
						$log = 0;
						break;					
					default:
						$sql = "SELECT * FROM config WHERE item = 'log'";
						if ($result = $mysqli->query($sql)) {
							if ($row = $result->fetch_array()) {
								$log = $row['value'];
							}
						}
				}
                
				$sql = "SELECT timestamp, temperature 
						  FROM logs
						 WHERE fermentation = '".$log."'
						   AND sensor = '".$sensor."'
						 ORDER BY timestamp ASC";
				
				if ($result = $mysqli->query($sql)) {
					while ($row = $result->fetch_array()) {
                        // convert unixtimestamp to highchart timestamp
						$ts_utc = $row['timestamp'] * 1000;
						$ts     = $ts_utc + (date('Z') * 1000);

                        if( $sensor == 99 ) {
                            if( $row['temperature'] == '1.00' )
                                $row['temperature'] = '2.00';
                        }
                        $values .= '[';
                        $values .= $ts.',';
                        $values .= $row['temperature'];
                        $values .= '],';
					}

					$values = delLastChar($values);
					$result->free();
				}
			}
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            $values = "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
		
		return $values;
    }
 ?>