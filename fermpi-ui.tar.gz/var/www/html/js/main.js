            <script type="text/javascript">
                function checkLogName(){
					var p = document.getElementById('profile');
					var l = document.getElementById('log-name');
					var v = l.value.trim();
					if(v !== '') {
                        p.disabled = false;
					}
					else {
						p.disabled = true;
					}
                }

				function profileChanged() {
					var s = document.getElementById('profile');
					var p = document.getElementById('phase-1');

					var idx = s.options[s.selectedIndex].value;
                    
                    if(idx > 0) {
						$.ajax({
							url: '/includes/js2php.php',
							type: 'POST',
							dataType: 'json',
							data: ({
								func: 'phpGetProfile',
								pid: idx
							}),
							success: function(obj, textstatus) {
								if( 'error' in obj ) {
									console.log("Error: " + obj.error);
								}
								else {
                                    document.getElementById('phase-1').style.display = 'block';                                    
									if(obj.id != '') {
										document.getElementById('t1').value = obj.t1;

                                        var btn = document.getElementById('start');
                                        btn.disabled = false;
                                        btn.style.color = '#000';

                                        if(obj.d1 != '') {
                                            document.getElementById('d1').value = obj.d1;
                                            document.getElementById('d1').disabled = false;
                                            document.getElementById('phase-2').style.display = 'block';                                    
                                            if(obj.t2 != '') {
                                                document.getElementById('t2').value = obj.t2;
                                                if(obj.d2 != '') {
                                                    document.getElementById('d2').value = obj.d2;
                                                    document.getElementById('d2').disabled = false;
                                                    document.getElementById('phase-3').style.display = 'block';
                                                    if(obj.t3 != '') {
                                                        document.getElementById('t3').value = obj.t3;
                                                        if(obj.d3 != '') {
                                                            document.getElementById('d3').value = obj.d3;
                                                            document.getElementById('d3').disabled = false;
                                                            document.getElementById('phase-4').style.display = 'block';
                                                            if(obj.t4 != '') {
                                                                document.getElementById('t4').value = obj.t4;
                                                                if( obj.d4 != '') {
                                                                    document.getElementById('d4').value = obj.d4;
                                                                    document.getElementById('d4').disabled = false;
                                                                    document.getElementById('phase-5').style.display = 'block';
                                                                    document.getElementById('t5').value = obj.t5;
                                                                    document.getElementById('d5').value = obj.d5;
                                                                    document.getElementById('d5').disabled = false;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
									}
									else {
										document.getElementById('t1').value = '';
										document.getElementById('d1').value = '';
										document.getElementById('t2').value = '';
										document.getElementById('d2').value = '';
										document.getElementById('t3').value = '';
										document.getElementById('d3').value = '';
										document.getElementById('t4').value = '';
										document.getElementById('d4').value = '';
										document.getElementById('t5').value = '';
										document.getElementById('d5').value = '';
									}
								}
							},
							error: function (jqXHR, exception) {
								var msg = '';
								if (jqXHR.status === 0) {
									msg = 'Not connect.\n Verify Network.';
								} else if (jqXHR.status == 404) {
									msg = 'Requested page not found. [404]';
								} else if (jqXHR.status == 500) {
									msg = 'Internal Server Error [500].';
								} else if (exception === 'parsererror') {
									msg = 'Requested JSON parse failed.';
								} else if (exception === 'timeout') {
									msg = 'Time out error.';
								} else if (exception === 'abort') {
									msg = 'Ajax request aborted.';
								} else {
									msg = 'Uncaught Error.\n' + jqXHR.responseText;
								}
								console.log(msg);
							},
						});

                        document.getElementById('phase-1').style.display = 'block';
					}
					else {
					}
				}

				function checkTemperature() {
					var e = this;
                    var next = null;
                    var enable = false;
					var btn = document.getElementById('start');
                    var t = parseFloat(this.value.trim());
                    if(isNaN(t)) {
                        t = 0;
                    }                    

                    if( t > 0) {
                        enable = true;
                    }
                    
					if(this.id === 't1') {
                        next = document.getElementById('d1');
						if(enable === true) {
							btn.disabled = false;
							btn.style.color = '#000';
						}
						else {
							btn.disabled = true;
							btn.style.color = '#bbb';
						}
					}
                    else if(this.id === 't2') {
                        next = document.getElementById('d2');
                    }
                    else if(this.id === 't3') {
                        next = document.getElementById('d3');
                    }
                    else if(this.id === 't4') {
                        next = document.getElementById('d4');
                    }
                    else if(this.id === 't5') {
                        next = document.getElementById('d5');
                    }

                    if(next !== null) {
                        if(enable === true) {
                            next.disabled = false;                    
                        }
                        else {
                            next.disabled = true;
                        }
                    }
				}

				function checkDuration() {
					var e = this;
                    var next = null;
                    var enable = false;
                    var d = parseInt(this.value.trim());
                    if(isNaN(d)) {
                        d = 0;
                    }                    
                    
                    if(d > 0) {
                        enable = true;
                    }
                    
					if(this.id === 'd1') {
                        next = document.getElementById('phase-2');
                        if(d > 0) {
                            btn.disabled = false;
                            btn.style.color = '#000';
						}
						else {
							btn.disabled = true;
							btn.style.color = '#bbb';
						}
					}
                    else if(this.id === 'd2') {
                        next = document.getElementById('phase-3');
                    }
                    else if(this.id === 'd3') {
                        next = document.getElementById('phase-4');
                    }
                    else if(this.id === 'd4') {
                        next = document.getElementById('phase-5');
                    }
                    
                    if(next !== null) {
                        if(enable === true) {
                            next.style.display = 'block';
                        }
                        else {
                            next.style.display = 'none';
                        }
                    }

                    document.getElementById('start').style.bottom = '0px';
				}

				function buttonClicked() {
					var log = t1 = d1 = t2 = d2 = t3 = d3 = t4 = d4 = t5 = d5 = '';

					var del = document.getElementById('delete').value.trim();

					if(this.id === 'start') {
						ln = document.getElementById('log-name').value.trim();
						t1 = document.getElementById('t1').value.trim();
						d1 = document.getElementById('d1').value.trim();

						if(d1 !== '') {
							t2 = document.getElementById('t2').value.trim();
							d2 = document.getElementById('d2').value.trim();
							if(d2 !== '') {
								t3 = document.getElementById('t3').value.trim();
								d3 = document.getElementById('d3').value.trim();
								if(d3 !== '') {
									t4 = document.getElementById('t4').value.trim();
									d4 = document.getElementById('d4').value.trim();
                                    if(d4 !== '') {
                                        t5 = document.getElementById('t4').value.trim();
                                        d5 = document.getElementById('d4').value.trim();
                                    }
								}
							}
						}

						$.ajax({
							url: "/includes/js2php.php",
							type: "POST",
							dataType: 'json',
							data: ({
								func: 'phpStartFermentation',
								log: ln,
								tmp1: t1,
								dur1: d1,
								tmp2: t2,
								dur2: d2,
								tmp3: t3,
								dur3: d3,
								tmp4: t4,
								dur4: d4,
                                tmp5: t5,
                                dur5: d5,
							}),
							success: function(obj, textstatus) {
								if('error' in obj) {
									if(obj.error == '1') {
										var msg = "Die Fermentierung '" + ln + "' existiert bereits. Möchten Sie diesen";
										msg += "\nEintrag, einschl. der zughörigen Log-Daten, wirklich löschen?";
										if(confirm( msg )) {
											document.getElementById('delete').value = '1';
											$("#start").trigger("click");
										}
									}
									else {
										console.log('Error: ' + obj.error);
									}
								}
								else {
									document.getElementById('myModal').style.display = "none";
								}
							},
							error: function (jqXHR, exception) {
								var msg = '';
								if (jqXHR.status === 0) {
									msg = 'Not connect.\n Verify Network.';
								} else if (jqXHR.status == 404) {
									msg = 'Requested page not found. [404]';
								} else if (jqXHR.status == 500) {
									msg = 'Internal Server Error [500].';
								} else if (exception === 'parsererror') {
									msg = 'Requested JSON parse failed.';
								} else if (exception === 'timeout') {
									msg = 'Time out error.';
								} else if (exception === 'abort') {
									msg = 'Ajax request aborted.';
								} else {
									msg = 'Uncaught Error.\n' + jqXHR.responseText;
								}
								console.log(msg);
							},
						});
					}
				}
			</script>
            <script type="text/javascript">
                $(function () {
                    $(document).ready(function() {
						var e;
						e = document.getElementById('log-name');
						e.addEventListener("input", checkLogName);
						e = document.getElementById('profile');
						e.addEventListener("change", profileChanged);
						e = document.getElementById('t1');
						e.addEventListener("input", checkTemperature);
						e = document.getElementById('d1');
						e.addEventListener("input", checkDuration);
						e = document.getElementById('t2');
						e.addEventListener("input", checkTemperature);
						e = document.getElementById('d2');
						e.addEventListener("input", checkDuration);
						e = document.getElementById('t3');
						e.addEventListener("input", checkTemperature);
						e = document.getElementById('d3');
						e.addEventListener("input", checkDuration);
						e = document.getElementById('t4');
						e.addEventListener("input", checkTemperature);
						e = document.getElementById('d4');
						e.addEventListener("input", checkDuration);
						e = document.getElementById('t5');
						e.addEventListener("input", checkTemperature);
						e = document.getElementById('start');
						e.addEventListener("click", buttonClicked);
					});
                });
            </script>
            <script type="text/javascript">
                $(function () {
                    $(document).ready(function() {
                        updateData();
                    });
                });
            </script>
            <script type="text/javascript">
                $(function () {
                    $(document).ready(function() {
                        for( i = 0; i < 100; i++ ) {
                            $.ajax({
                                url: '/includes/js2php.php',
                                type: 'POST',
                                dataType: 'json',
                                data: ({
                                    func: 'phpGetProfileName',
                                    pid: i
                                }),
                                success: function(obj, textstatus) {
                                    if( 'error' in obj ) {
                                        console.log("Error: " + obj.error);
                                    }
                                    else if(obj.name != '') {
                                        var opt = document.createElement('option');
                                        opt.value = obj.id;
                                        opt.innerHTML = obj.name;
                                        document.getElementById('profile').appendChild(opt);
                                    }
                                },
                                error: function (jqXHR, exception) {
                                    var msg = '';
                                    if (jqXHR.status === 0) {
                                        msg = 'Not connect.\n Verify Network.';
                                    } else if (jqXHR.status == 404) {
                                        msg = 'Requested page not found. [404]';
                                    } else if (jqXHR.status == 500) {
                                        msg = 'Internal Server Error [500].';
                                    } else if (exception === 'parsererror') {
                                        msg = 'Requested JSON parse failed.';
                                    } else if (exception === 'timeout') {
                                        msg = 'Time out error.';
                                    } else if (exception === 'abort') {
                                        msg = 'Ajax request aborted.';
                                    } else {
                                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                                    }
                                    console.log(msg);
                                },
                            });
                        }
                    });
                });
            </script>
 			<script type="text/javascript">
				function jsGetState() {
                    $.ajax({
                        url: '/includes/js2php.php',
                        type: 'POST',
						dataType: 'json',
						data: ({
							func: 'phpGetState',
							ts: 0
						}),
						success: function(obj, textstatus) {
							if( 'error' in obj ) {
								console.log("Error: " + obj.error);
							}
						},
						error: function (jqXHR, exception) {
							var msg = '';
							if (jqXHR.status === 0) {
								msg = 'Not connect.\n Verify Network.';
							} else if (jqXHR.status == 404) {
								msg = 'Requested page not found. [404]';
							} else if (jqXHR.status == 500) {
								msg = 'Internal Server Error [500].';
							} else if (exception === 'parsererror') {
								msg = 'Requested JSON parse failed.';
							} else if (exception === 'timeout') {
								msg = 'Time out error.';
							} else if (exception === 'abort') {
								msg = 'Ajax request aborted.';
							} else {
								msg = 'Uncaught Error.\n' + jqXHR.responseText;
							}
							console.log(msg);
						},
                    });
				}
            </script>
 			<script type="text/javascript">
				function jsSetState() {
					var new_state = 0;
					if(document.getElementById('power').checked === true) {
						new_state = 1;
					}
                    $.ajax({
                        url: '/includes/js2php.php',
                        type: 'POST',
						dataType: 'json',
						data: ({
							func: 'phpSetState',
							state: new_state
						}),
						success: function(obj, textstatus) {
							if( 'error' in obj ) {
								console.log("Error: " + obj.error);
								document.getElementById('power').checked = !document.getElementById('power').checked;
							}
						},
						error: function (jqXHR, exception) {
							var msg = '';
							if (jqXHR.status === 0) {
								msg = 'Not connect.\n Verify Network.';
							} else if (jqXHR.status == 404) {
								msg = 'Requested page not found. [404]';
							} else if (jqXHR.status == 500) {
								msg = 'Internal Server Error [500].';
							} else if (exception === 'parsererror') {
								msg = 'Requested JSON parse failed.';
							} else if (exception === 'timeout') {
								msg = 'Time out error.';
							} else if (exception === 'abort') {
								msg = 'Ajax request aborted.';
							} else {
								msg = 'Uncaught Error.\n' + jqXHR.responseText;
							}
							console.log(msg);
						},
                    });
				}
            </script>
            <script type="text/javascript">
                function updateData(){
					p = document.getElementById('timestamp').value;
                    $.ajax({
							url: '/includes/js2php.php',
							type: 'POST',
							dataType: 'json',
							data: ({
								func: 'phpGetState',
								ts: p
							}),
							success: function(obj, textstatus) {
								if( 'error' in obj ) {
									console.log("Error: " + obj.error);
								}
								else {
									var chart = $('#chart_container').highcharts();
									var s1 = chart.get('series-1');
									var s2 = chart.get('series-2');
									var s3 = chart.get('series-3');

									if(obj.state == 0 && s1.data.length > 0) {
										location.reload();
									}
									else  {
										if(obj.state == 1) {
											document.getElementById('pi-state').innerHTML = 'an';
											document.getElementById('power').checked = 1;

											if(obj.mode == 0) {
												document.getElementById('pi-mode').innerHTML = 'Leerlauf';
												obj.target = '-';
                                                obj.duration = '-';
											}
											else if(obj.mode == 1) {
												document.getElementById('pi-mode').innerHTML = 'konstante Temperatur';
                                                if(obj.duration == '' ) {
                                                    obj.duration = '&infin;';
                                                }
											}
											else if(obj.mode == 2) {
												document.getElementById('pi-mode').innerHTML = 'graduelle Temperatur';
											}
                                            else {
												document.getElementById('pi-mode').innerHTML = 'unbekannter Modus';
                                                if(obj.duration == '' ) {
                                                    obj.duration = '&infin;';
                                                }
                                            }

											if(obj.s1 != '') {
												document.getElementById('pi-s1').innerHTML = obj.s1;
											}
                                            else {
												document.getElementById('pi-s1').innerHTML = '-';
                                            }

											if(obj.s2 != '') {
												document.getElementById('pi-s2').innerHTML = obj.s2;
											}
                                            else {
												document.getElementById('pi-s2').innerHTML = '-';
                                            }
                                            
                                            if(obj.target != '') {
                                                document.getElementById('target').innerHTML = obj.target;
                                            }
                                            else {
                                                document.getElementById('target').innerHTML = '-';
                                            }
                                            
                                            if(obj.duration != '') {
                                                if(obj.duration != '0') {
                                                    document.getElementById('duration').innerHTML = obj.duration;
                                                }
                                                else {
                                                    document.getElementById('duration').innerHTML = '&infin;';
                                                }
                                                    
                                            }
                                            else {
                                                document.getElementById('duration').innerHTML = '-';
                                            }
                                            
											if(obj.fermentation == '') {
												document.getElementById('fermentation').innerHTML = '-';
											}
											else {
												document.getElementById('fermentation').innerHTML = obj.fermentation;
											}

											if(obj.ts_utc > 0) {
												document.getElementById('timestamp').value = obj.ts_utc;

												if(obj.s1 > 0)
													s1.addPoint([obj.ts_local, parseFloat(obj.s1)], false, false, false);
												if(obj.s2 > 0)
													s2.addPoint([obj.ts_local, parseFloat(obj.s2)], false, false, false);
												if(obj.target > 0)
													s3.addPoint([obj.ts_local, parseFloat(obj.target)], false, false, false);

												chart.redraw();
											}
										}
										else {
											document.getElementById('pi-state').innerHTML = 'aus';
											document.getElementById('power').checked = 0;
											document.getElementById('pi-mode').innerHTML = '-';
											document.getElementById('pi-s1').innerHTML = '-';
											document.getElementById('pi-s2').innerHTML = '-';
											document.getElementById('target').innerHTML = '-';
											document.getElementById('duration').innerHTML = '-';
											document.getElementById('fermentation').innerHTML = '-';
											document.getElementById('timestamp').value = '';
										}
									}
								}
							},
							error: function (jqXHR, exception) {
								var msg = '';
								if (jqXHR.status === 0) {
									msg = 'Not connect.\n Verify Network.';
								} else if (jqXHR.status == 404) {
									msg = 'Requested page not found. [404]';
								} else if (jqXHR.status == 500) {
									msg = 'Internal Server Error [500].';
								} else if (exception === 'parsererror') {
									msg = 'Requested JSON parse failed.';
								} else if (exception === 'timeout') {
									msg = 'Time out error.';
								} else if (exception === 'abort') {
									msg = 'Ajax request aborted.';
								} else {
									msg = 'Uncaught Error.\n' + jqXHR.responseText;
								}
								console.log(msg);
							},
                    });
                }
                setInterval(updateData, 5000);
            </script>
            <script type="text/javascript">
                $(function () {
                    $(document).ready(function() {
						Highcharts.setOptions({
							global: {
								useUTC: false
							},
							lang: {
								months: ['Jan', 'Feb', 'Mrz', 'Apr', 'Mai', 'Jun',  'Jul', 'Aug', 'Sept', 'Okt', 'Nov', 'Dez'],
								weekdays: ['Sonntage', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag']
							}
						});
						Highcharts.stockChart('chart_container', {
							plotOptions: {
								series: {
									animation: {
										duration: 1000
									}
								}
							},
							rangeSelector: {
								inputEnabled: false,
								buttons: [{
									type: 'hour',
									count: 1,
									text: '1'
								}, {
									type: 'hour',
									count: 6,
									text: '6'
								}, {
									type: 'hour',
									count: 12,
									text: '12'
								}, {
									type: 'day',
									text: 'Tag'
								}, {
									type: 'all',
									text: 'Alles'
								}],
								selected: 4,

							},
							xAxis: {
								title: {
									text: 'Zeit'
								},
								type: 'datetime',
								dateTimeLabelFormats: {
									minute: '%H:%M'
								},
							},
							yAxis: {
								opposite: false,
								title: {
									text: 'Temperatur',
								},
								labels: {
									formatter: function () {
										var n = this.value;
										return n.toFixed(0);
									}
								},
							},
							tooltip: {
								split: true,
								padding: 4,
								valueDecimals: 2,
								valueSuffix: ' °C'
							},
							legend: {
								enabled: true,
								align: 'right',
								verticalAlign: 'top',
								layout: 'vertical',
								x: 0,
								y: 50,
								title: {
									text: 'Temperaturen',
									style: {
										color: '#415F9C',
									}
								},
								itemStyle: {
									fontSize: '10px',
									fontWeight: 'bold'
								},
								backgroundColor: '#FFFFFF',
								borderColor: '#FFFFFF',
								borderWidth: 1,
								borderRadius: 3,
								shadow: {
									color: '#000000',
									offsetX: 1,
									offsetY: 1,
									width: 4
								},
								labelFormatter: function() {
									return this.name;
								}
							},
							series: [{
								id: 'series-1',
								type: 'spline',
								name: 'Sensor 1',
								color: '#415F9C',
								data: [<?php echo $vData1;?>],
								marker: {
									enabled: false
								}
							}, {
								id: 'series-2',
								type: 'spline',
								name: 'Sensor 2',
								data: [<?php echo $vData2;?>],
								marker: {
									enabled: false
								}
							}, {
								id: 'series-3',
								type: 'spline',
								name: 'Soll',
								color: '#FF0000',
								lineWidth: 1,
								data: [<?php echo $vData3;?>],
								marker: {
									enabled: false
								}
							}]
						});
                    });
                });
            </script>
