        <!-- main.php -->
            <script src="js/highstock/highstock.js"></script>
            <script src="js/highstock/highcharts-more.js"></script>
<?php $vUTC    = utcTimestamp();?>
<?php $vStatus = getStatus();?>
<?php $vData1  = getTemperatureChartValues(1);?>
<?php $vData2  = getTemperatureChartValues(2);?>
<?php $vData3  = getTemperatureChartValues(0);?>
<?php include_once('js/main.js');?>
            <h1>Übersicht</h1>
            <div class="content">
				<!-- The Modal -->
				<div id="myModal" class="modal">
				  <!-- Modal content -->
				  <div class="modal-content">
					<div class="modal-header">
					  <span class="close">&times;</span>
					  <span class="title">Fermentierung</span>
					</div>
					<div class="modal-body">
					  <div class="modal-line">
					    <span class="setting-name">Name:</span>
						<span class="setting-input-span">
						  <input type="text" id="log-name" class="modal-input">
					      <input type="hidden" id="delete" value="">
						  <button disabled="true" type="button" id="start" class="modal-start">Start</button>
						</span>
                        <span class="setting-explanation">
						  Unter diesem Namen werden die Daten aufgezeichnet und können jederzeit
						  nach der Fermentierung unter dem Menüpunkt 'Logbuch' erneut betrachtet werden.
						</span>
					  </div>
					  <div class="modal-line">
					    <span class="setting-name">Profil:</span>
						<span class="setting-input-span">
					      <select disabled="true" id="profile" class="modal-selection">
					        <option value="0"></option>
					      </select>
						</span>
						<span class="setting-explanation">
						  Durch Auswahl eines Profiles wird der Modus und die Temperatur(en) bestimmt.
                          			  Die einzelnen Parameter können angepasst werden.
						</span>
					  </div>
					  <div class="phase-line" id="phase-1">
					    <fieldset class="field-set">
						  <legend class="field-legend">&nbsp;Phase 1&nbsp;</legend>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Temperatur:</span>
						    <span class="phase-input-span">
							  <input type="text" id="t1" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
							  Temperatur der ersten Phase.
						    </span>
						  </div>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Dauer:</span>
						    <span class="phase-input-span">
						      <input disabled="true" type="text" id="d1" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
						      Bleibt das Feld leer, muss die Fermentierung manuell beendet werden.
						    </span>
						  </div>
					    </fieldset>
					  </div>
					  <div class="phase-line" id="phase-2">
					    <fieldset class="field-set">
						  <legend class="field-legend">&nbsp;Phase 2&nbsp;</legend>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Temperatur:</span>
						    <span class="phase-input-span">
							  <input type="text" id="t2" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
							  Temperatur der zweiten Phase.
						    </span>
						  </div>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Dauer:</span>
						    <span class="phase-input-span">
						      <input disabled="true" type="text" id="d2" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
						      Bleibt das Feld leer, muss die Fermentierung manuell beendet werden.
						    </span>
						  </div>
					    </fieldset>
					  </div>
					  <div class="phase-line" id="phase-3">
					    <fieldset class="field-set">
						  <legend class="field-legend">&nbsp;Phase 3&nbsp;</legend>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Temperatur:</span>
						    <span class="phase-input-span">
							  <input type="text" id="t3" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
							  Temperatur der dritten Phase.
						    </span>
						  </div>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Dauer:</span>
						    <span class="phase-input-span">
						      <input disabled="true" type="text" id="d3" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
						      Bleibt das Feld leer, muss die Fermentierung manuell beendet werden.
						    </span>
						  </div>
					    </fieldset>
					  </div>
					  <div class="phase-line" id="phase-4">
					    <fieldset class="field-set">
						  <legend class="field-legend">&nbsp;Phase 4&nbsp;</legend>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Temperatur:</span>
						    <span class="phase-input-span">
							  <input type="text" id="t4" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
							  Temperatur der vierten Phase.
						    </span>
						  </div>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Dauer:</span>
						    <span class="phase-input-span">
						      <input disabled="true"  type="text" id="d4" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
						      Bleibt das Feld leer, muss die Fermentierung manuell beendet werden.
						    </span>
						  </div>
					    </fieldset>
					  </div>
					  <div class="phase-line" id="phase-5">
					    <fieldset class="field-set">
						  <legend class="field-legend">&nbsp;Phase 5&nbsp;</legend>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Temperatur:</span>
						    <span class="phase-input-span">
							  <input type="text" id="t5" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
							  Temperatur der fünften Phase.
						    </span>
						  </div>
						  <div class="fieldset-line">
						    <span class="phase-setting-name">Dauer:</span>
						    <span class="phase-input-span">
						      <input disabled="true" type="text" id="d5" class="modal-input">
						    </span>
						    <span class="phase-setting-explanation">
						      Bleibt das Feld leer, muss die Fermentierung manuell beendet werden.
						    </span>
						  </div>
					    </fieldset>
					  </div>
					</div> <!-- modal-body -->
				  </div> <!-- modal-content -->
				</div> <!-- myModal -->
                <div class="line">
                    <ul class="d1">
                        <li style="font-size: 0.75em">Status:</li>
                        <li style="font-size: 0.75em">Modus:</li>
                    </ul>
                    <ul class="d2">
                        <li id="pi-state" style="font-size: 0.75em; text-align: left; width: 180px;"><?php echo $vStatus['status'];?></li>
                        <li id="pi-mode" style="font-size: 0.75em; text-align: left; width: 180px;"><?php echo $vStatus['mode'];?></li>
                    </ul>
                    <ul class="d1">
                        <li style="font-size: 0.75em">Sensor 1:</li>
                        <li style="font-size: 0.75em">Sensor 2:</li>
                    </ul>
                    <ul class="d2">
                        <li id="pi-s1" style="font-size: 0.75em; text-align: left; width: 30px;"><?php echo $vStatus['s1'];?></li>
                        <li id="pi-s2" style="font-size: 0.75em; text-align: left; width: 30px;"><?php echo $vStatus['s2'];?></li>
                    </ul>
                    <ul class="d2c">
                        <li style="font-size: 0.75em; width: 50px">°C</li>
                        <li style="font-size: 0.75em; width: 50px">°C</li>
                    </ul>
                    <ul class="d1">
                        <li style="font-size: 0.75em">Soll:</li>
                        <li style="font-size: 0.75em">Dauer:</li>
                    </ul>
                    <ul class="d2">
                        <li id="target" style="font-size: 0.75em; text-align: left; width: 30px;"><?php echo $vStatus['target'];?></li>
                        <li id="duration" style="font-size: 0.75em; text-align: left; width: 30px;"></li>
                    </ul>
                    <ul class="d2c">
                        <li style="font-size: 0.75em">°C</li>
                    </ul>
                    <ul class="d3">
						<div style="clear: both; position: relative; left: 100px; top: 0px;">
							<li class="onoffswitch">
								<input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="power" onchange="jsSetState()">
								<label class="onoffswitch-label" for="power">
									<span class="onoffswitch-inner"></span>
									<span class="onoffswitch-switch"></span>
								</label>
							</li>
						</div>
                    </ul>
                </div>
                <div class="line">
                    <ul class="d4" style="margin-top: 70px">
                        <li>
						    <span style="font-size: 0.95em; font-weight: normal;">Fermentierung:</span>
							<span>
								<button id="fermentation" style="height: 1.7em; min-width: 12em; vertical-align: center; font-size: 0.95em; font-weight: normal;">&nbsp;-&nbsp;</button>
							</span>
						</li>
                    </ul>
                </div>
                <div class="line">
					<input type="hidden" id="timestamp" value="<?php echo $vUTC;?>">
                    <div id="chart_container"></div>
                </div>
            </div>
			<script>
				// Get the modal
				var modal = document.getElementById('myModal');

				// Get the link that opens the modal
				var btn = document.getElementById("fermentation");

				// Get the <span> element that closes the modal
				var span = document.getElementsByClassName("close")[0];

				// When the user clicks the button, open the modal 
				btn.onclick = function() {
					modal.style.display = "block";
				}

				// When the user clicks on <span> (x), close the modal
				span.onclick = function() {
					modal.style.display = "none";
				}
				// When the user clicks anywhere outside of the modal, close it
				window.onclick = function(event) {
					if (event.target == modal) {
						modal.style.display = "none";
					}
				}
			</script>
        <!-- main.php --> 
