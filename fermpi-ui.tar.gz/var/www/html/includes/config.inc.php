<?php
    $site_title     = "FermPi - Fermentation Controller";
    $site_charset   = "utf-8";

    define('DB_SERVER', "<db server>");       	                                 // Server
    define('DB_NAME', "<db name>");            	                                 // Database
    define('DB_USER', "<user>");                                                 // Username
    define('DB_PASSWORD', "<password>");                                         // Password

    define('PDO_DB_DSN', 'mysql:host=<db host>;dbname=<db name>;charset=utf8'); // Data Source Name (DSN)
    define('PDO_DB_USER','<db user>');                                          // Benutzername
    define('PDO_DB_PWD','<db password');                                        // Passwort
?>
