<?php
	include_once("config.inc.php");

    function debug_to_console( $msg ) {
        echo("<script>console.log(".$state.")</script>");
    }        
    
	function pdoConnect() {
		$r = new PDO( PDO_DB_DSN, PDO_DB_USER, PDO_DB_PWD );
		$r->setAttribute( PDO::ATTR_EMULATE_PREPARES, false );
		$r->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		return $r;
	}
	
	function phpStartFermentation( $log, $t1, $d1, $t2, $d2, $t3, $d3, $t4, $d4, $t5, $d5 ) {
		$error = '';
		$phases = array( 't1' => '',   'd1' => null,
						 't2' => null, 'd2' => null,
						 't3' => null, 'd3' => null,
						 't4' => null, 'd4' => null,
                         't5' => null, 'd5' => null );

        $a = array();

		if( !trim( $log ) )
			 $error = "Error: Parameter 'log' missing or empty";
		elseif( !trim( $t1 ) )
			 $error = "Error: Parameter 't1' missing or empty";
		
		if( $error != '' ) {
			$a['error'] = $error;
		}
		else {
			$phases['t1'] = trim( $t1 );
            if( trim( $d1 ) != '' )
                $phases['d1'] = trim( $d1 );
            if( trim( $t2 ) != '' )
                $phases['t2'] = trim( $t2 );
            if( trim( $d2 ) != '' )
                $phases['d2'] = trim( $d2 );
            if( trim( $t3 ) != '' )
                $phases['t3'] = trim( $t3 );
            if( trim( $d3 ) != '' )
                $phases['d3'] = trim( $d3 );
            if( trim( $t4 ) != '' )
                $phases['t4'] = trim( $t4 );
            if( trim( $d4 ) != '' )
                $phases['d4'] = trim( $d4 );
            if( trim( $t5 ) != '' )
                $phases['t5'] = trim( $t5 );
            if( trim( $d5 ) != '' )
                $phases['d5'] = trim( $d5 );
			
			try {
				$lid = 0;
				$bStart = false;
                $name = $log." ".date('Y-m-d H:i:s');
                
				$pdo  = pdoConnect();
				$stmt = $pdo->query( "SELECT id FROM fermentations WHERE name = '".$name."'" );
				if( $row = $stmt->fetch() ) {
					$lid = $row['id'];
					
                    $stmt = $pdo->query( "DELETE FROM logs WHERE fermentation = '".$lid."'" );
                    
                    $stmt = $pdo->prepare( "UPDATE fermentations
											SET t1 = :t1, d1 = :d1,
												t2 = :t2, d2 = :d2,
												t3 = :t3, d3 = :d3,
												t4 = :t4, d4 = :d4,
                                                t5 = :t5, d5 = :d5
											WHERE id = :id" );
						
					$stmt->execute( array (	':t1' => $phases['t1'], ':d1' => $phases['d1'], 
											':t2' => $phases['t2'], ':d2' => $phases['d2'], 
											':t3' => $phases['t3'], ':d3' => $phases['d3'], 
											':t4' => $phases['t4'], ':d4' => $phases['d4'],
											':t5' => $phases['t5'], ':d5' => $phases['d5'],
											':id' => $lid ) );
					
					$bStart = true;
				}
				else {					
					$stmt = $pdo->prepare( "INSERT INTO fermentations ( name, t1, d1, t2, d2, t3, d3, t4, d4, t5, d5 )
										    VALUES( :name, :t1, :d1, :t2, :d2, :t3, :d3, :t4, :d4, :t5, :d5 )" );
					
					$stmt->execute( array( ':name' => $name,
					                       ':t1' => $phases['t1'],
										   ':d1' => $phases['d1'],
					                       ':t2' => $phases['t2'],
										   ':d2' => $phases['d2'],
					                       ':t3' => $phases['t3'],
										   ':d3' => $phases['d3'],
					                       ':t4' => $phases['t4'],
										   ':d4' => $phases['d4'],
					                       ':t5' => $phases['t5'],
										   ':d5' => $phases['d5']
                                           ) );
					
                    $stmt = $pdo->query( "SELECT id FROM fermentations WHERE name = '".$name."'" );
                    if( $row = $stmt->fetch() ) {
                        $lid = $row['id'];
                        $bStart = true;
                    }
				}
				
				if( $bStart ) {
					$stmt = $pdo->prepare( "UPDATE config SET value = :value WHERE item = 'log'" );
					$stmt->execute( array( ':value' => $lid ) );
                    $stmt = $pdo->prepare( "UPDATE config SET value = :value WHERE item = 'mode'" );
                    if( $phases['d1'] == '' ) 
                        $stmt->execute( array( ':value' => 1 ) );
                    else
                        $stmt->execute( array( ':value' => 2 ) );
                    
					$stmt = $pdo->prepare( "UPDATE config SET value = :value WHERE item = 'state'" );
					$stmt->execute( array( ':value' => 1 ) );
				}
			}
			catch( PDOException $e ) {
				$error = 'MYSQL Error ('.$e->getCode().'): '.$e->getMessage();
			}
		}
		
		if( $error != '' ) {$a['error'] = $error;}
		else {$a['state'] = $state;}
		
		return $a;
	}
	
	function phpSetState( $state ) {
		$error = '';
		$a = array();
		
		try {
			$pdo = pdoConnect();			
			$stmt = $pdo->prepare("UPDATE config SET value = :value WHERE item = 'state'");
			$stmt->execute(array(':value' => $state));		
			
			if( $state == 0 ) {
				$stmt = $pdo->query("UPDATE config SET value = 0 WHERE item = 'log'");
			}
		}
		catch( PDOException $e ) {
			$error = 'MYSQL Error ('.$e->getCode().'): '.$e->getMessage();
		}
		
		if( $error != '' ) {$a['error'] = $error;}
		else {$a['state'] = $state;}
		
		return $a;
	}
	
	function phpGetState( $prev_ts = '' ) {
		$error = '';
		$state = '';
		$mode = '';
		$log = '';
        $target = '';
        $duration = '';
        
		$fermentation = '';
		$sensor_1 = '';
		$sensor_2 = '';
		$target = '';
		$ts_utc = '0';
		$ts_local = '0';
		$id = '';
		
		$a = array();
		
		try {
			$pdo = pdoConnect();
			$stmt = $pdo->query( "SELECT item, value FROM config WHERE 1" );
			
			while( $data = $stmt->fetch() ) {
				switch( $data['item'] ) {
					case 'state':
						$state = $data['value'];
						break;
					case 'mode':
						$mode = $data['value'];
						break;
					case 'log':
						$log = $data['value'];
						break;
					case 'target':
						$target = $data['value'];
						break;
					case 'duration':
						$duration = $data['value'];
						break;
					default:
						// unknown config column
				}
			}
				
			if( $state == 1 ) {
				$stmt = $pdo->query( "SELECT name FROM fermentations WHERE id = '".$log."'" );
				if( ($row = $stmt->fetch()) ) {
					$fermentation = $row['name'];
				}

				if( $prev_ts == '') {
					$stmt = $pdo->query( "SELECT timestamp
											FROM logs
										   WHERE fermentation = '".$log."'
									       ORDER BY TIMESTAMP DESC
									       LIMIT 1" );
					if( ($row = $stmt->fetch()) ) {
						$ts_utc   = $row['timestamp'];
						$ts_local = $ts_utc + (date('Z') * 1000);
					}
				}
				else {
					$stmt = $pdo->query( "SELECT *
											FROM logs
										   WHERE fermentation = '".$log."'
											 AND timestamp >= '".$prev_ts."'
										   ORDER BY timestamp DESC
										   LIMIT 1" );
					if( ($row = $stmt->fetch()) ) {
						if( $row['timestamp'] > $prev_ts ) {
							$ts_utc   = $row['timestamp'];
                            $ts_local = $ts_utc + (date('Z') * 1000);
						}

						$id = $row['id'];
							
                        switch( $row['sensor'] ) {
							case '0':
								$target   = $row['temperature'];
								break;
							case '1':
								$sensor_1 = $row['temperature'];
								break;
							case '2':
								$sensor_2 = $row['temperature'];
								break;
                            default:
                                break;
                        }
					}
				}
			}
		}
		catch( PDOException $e ) {
			$error = 'MYSQL Error ('.$e->getCode().'): '.$e->getMessage();
		}
		
		if( $error != '' ) {
			$a['error'] = $error;
		}
		else {
			$a['state'] = $state;
			$a['mode'] = $mode;
			$a['log'] = $log;
			$a['fermentation'] = $fermentation;
			$a['s1'] = $sensor_1;
			$a['s2'] = $sensor_2;
			$a['target'] = $target;
            $a['duration'] = $duration;
			$a['ts_utc'] = $ts_utc;
			$a['ts_local'] = $ts_local;
			$a['id'] = $id;
		}
		
		return $a;
	}

	function phpGetProfile( $pid ) {
		$error = '';
		$a = array();

		$id = '';
		$mode = '';
		$name = '';
		$t1 = '';
        $d1 = '';
		$t2 = '';
        $d2 = '';
		$t3 = '';
        $d3 = '';
		$t4 = '';
        $d4 = '';
		$t5 = '';
        $d5 = '';
        
		
		try {
			$pdo = pdoConnect();
			$stmt = $pdo->query( "SELECT * FROM profiles WHERE id = '".$pid."'" );
            if( ($row = $stmt->fetch()) ) {
                $id = $row['id'];
                $mode = $row['mode'];
                $name = $row['name'];
                $t1 = $row['t1'];
                if( $row['d1'] != NULL ) { $d1 = $row['d1']; }
                if( $row['t2'] != NULL ) { $t2 = $row['t2']; }
                if( $row['d2'] != NULL ) { $d2 = $row['d2']; }
                if( $row['t3'] != NULL ) { $t3 = $row['t3']; }
                if( $row['d3'] != NULL ) { $d3 = $row['d3']; }
                if( $row['t4'] != NULL ) { $t4 = $row['t4']; }
                if( $row['d4'] != NULL ) { $d4 = $row['d4']; }
                if( $row['t5'] != NULL ) { $t5 = $row['t5']; }
                if( $row['d5'] != NULL ) { $d5 = $row['d5']; }
			}
		}
		catch( PDOException $e ) {
			$error = 'MYSQL Error ('.$e->getCode().'): '.$e->getMessage();
		}
		
		if( $error != '' ) {
			$a['error'] = $error;
		}
		else {
			$a['id'] = $id;
			$a['mode'] = $mode;
			$a['name'] = $name;
			$a['t1'] = $t1;
			$a['d1'] = $d1;
			$a['t2'] = $t2;
			$a['d2'] = $d2;
			$a['t3'] = $t3;
			$a['d3'] = $d3;
			$a['t4'] = $t4;
			$a['d4'] = $d4;
			$a['t5'] = $t5;
			$a['d5'] = $d5;
		}
		
		return $a;
	}

	function phpGetProfileName( $pid ) {
		$a = array();

		$error = '';
		$id = '';
		$name = '';


		try {
			$pdo = pdoConnect();
			$stmt = $pdo->query( "SELECT id, name FROM profiles WHERE id = '".$pid."'" );
            if( ($row = $stmt->fetch()) ) {
                $id = $row['id'];
                $name = $row['name'];
			}
		}
		catch( PDOException $e ) {
			$error = 'MYSQL Error ('.$e->getCode().'): '.$e->getMessage();
		}

		if( $error != '' ) {
			$a['error'] = $error;
		}
		else {
			$a['id'] = $id;
			$a['name'] = $name;
		}
		
		return $a;
	}

    header('Content-Type: application/json');

    $aResult = array();

    if( !isset( $_POST['func'] ) ) {
		$aResult['error'] = 'No function name given';
	}
    else {
        switch( $_POST['func'] ) {
            case 'phpGetState':
				$aResult = phpGetState( $_POST['ts'] );
				break;
			
			case 'phpSetState':
				if( !isset( $_POST['state'] ) ) {
					$aResult['error'] = "Parameter 'state' is missing or empty.";
				}
				else {
					$aResult = phpSetState( $_POST['state'] );
				}
				break;
			
			case 'phpGetProfile':
				if( !isset( $_POST['pid'] ) ) {
					$aResult['error'] = "Parameter 'pid' is missing or empty.";
				}
				else {
					$aResult = phpGetProfile( $_POST['pid'] );
				}
				break;

			case 'phpGetProfileName':
				if( !isset( $_POST['pid'] ) ) {
					$aResult['error'] = "Parameter 'pid' is missing or empty.";
				}
				else {
					$aResult = phpGetProfileName( $_POST['pid'] );
				}
				break;
            
			case 'phpStartFermentation':
				if( !isset( $_POST['log'] ) ) {
					$aResult['error'] = "Parameter 'log' is missing or empty.";
					break;
				}
				if( !isset( $_POST['tmp1'] ) ) {
					$aResult['error'] = "Parameter 't1' is missing or empty.";
					break;
				}
				if( !isset( $_POST['dur1'] ) ) {
					$aResult['error'] = "Parameter 'd1' is missing or empty.";
					break;
				}
				
				$aResult = phpStartFermentation( $_POST['log'],
												 $_POST['tmp1'], $_POST['dur1'],
												 $_POST['tmp2'], $_POST['dur2'],
												 $_POST['tmp3'], $_POST['dur3'],
												 $_POST['tmp4'], $_POST['dur4'],
												 $_POST['tmp5'], $_POST['dur5'] );
				break;
				
            default:
               $aResult['error'] = 'Unknown function: '.$_POST['func'];
        }
    }
	
    echo json_encode($aResult);
?>