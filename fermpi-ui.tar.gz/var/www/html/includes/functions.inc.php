<?php
    function getHomematicSysVar($index, $id) {
        $value = NULL;
        
        $sysvarlist  = file_get_contents('http://'.HM_CCU_IP.'/config/xmlapi/sysvarlist.cgi'); 
        $xml_elements = simplexml_load_string($sysvarlist);
        
        foreach($xml_elements->systemVariable as $sysvar) {
            if($sysvar['ise_id'] == $id) {
                $value = $sysvar[$index];
                break;
            }
        }
        
        return $value;
    }

    function feedCompensation($y, $m, $d) {
        $r = 0.1231;     //aktuelle Vergütung

        if (checkdate( $m, $d, $y )) {
            $d = sprintf( "$d-$d-$d", $y, $m, $d );
            if (compareDate( $d, "2016-1-1" ) < 0)
                $r = 0.1243;
            else
                $r = 0.1231;
        }

        return $r;
    }
    
    function monthName( $m ) {
        $a = array( "Januar","Februar","März","April","Mai","Juni",
                    "Juli","August","September","Oktober","November","Dezember" );
        return $a[$m-1];
    }
    
    function compareDate( $date_1, $date_2 ) {
        $r = 0;
        
        $ts_1 = strtotime( $date_1 );
        $ts_2 = strtotime( $date_2 );
         
        if ($ts_1 > $ts_2)
            $r = 1;
        else if ($ts_1 < $ts_2)
            $r = -1;

        return $r;
    }
   
    function monthTargets() {
        return array( 15.410, 28.020,126.070,
                     142.880,164.310,196.390,
                     205.820,205.780,154.090,
                     120.610, 25.210, 15.410 );
    }
    
    function yearTarget($y, $m, $d) {
        $r = 0;
        
        if( $m >= 1 && $m <= 12 ) {
            $s = 1;
            if( $y == 2015 )
                $s = 5;
            
            for( $i = $s; $i <= $m; $i++ ) {
                $r += monthTarget($y, $i, $d);
            }
        }

        return $r;
    }

    function monthTarget($y, $m, $d) {
        $r = 0;
        
        $d_today = date("j");
        $m_today = date("n");
        $y_today = date("Y");
        
        $days = cal_days_in_month(CAL_GREGORIAN, $m, $y);
        
        if ($m >= 1 && $m <= 12) {
            $a = monthTargets();
            if (($y == $y_today) && ($m == $m_today)) {
                $r = sprintf("%.3f", ($a[$m-1] / $days * $d_today) );
            }
            else {
                $r = $a[$m-1];
            }
        }
        
        return $r;
    }
    
    function dayTargets( $y, $m ) {
        $r = array ();

        $m = intval( $m );
        $t = dayTarget( $y, $m );
        $j = cal_days_in_month( CAL_GREGORIAN, $m, $y );
        for ($i=0; $i<$j; $i++) {
            $r[$i] = sprintf( "%.3f", $t );
        }
        
        return $r;
    }

    function dayTarget( $y, $m ) {
        $r = 0;

        $m = intval( $m );
        if ($m >= 1 && $m <= 12) {
            $a = monthTargets();
            $r = ($a[$m-1] / cal_days_in_month( CAL_GREGORIAN, $m, $y ));
        }
        
        return $r;
    }
    
    function database_skeleton() {

        // create database object
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            // do more stuff here
            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
    }
   
    /*****************************************************
    * Function: validPlantDate( year, month, day )
    *
    * Desc: checks if the given date is valid in terms of
    *       PHP language requirements and that the solar 
    *       plant already existed.
    *
    * Return: 1 = invalid or in the future
    *         0 = today
    *        -1 = earlier than plant launch (06.05.2015)
    */
    function validPlantDate( $y, $m, $d ) {

        if (!checkdate( $m, $d, $y ))
            return 1;
        
        if(     ($y<2015)
            || (($y==2015) && ($m<5))
            || (($y==2015) && ($m==5) && ($d<6)) ) { 
            return -1; 
        }
        
        $cy = date( 'Y' );
        $cm = date( "m" );
        $cd = date( "d" );
        
        if(     ($y>$cy)
            || (($y==$cy) && ($m>$cm))
            || (($y==$cy) && ($m==$cm) && ($d>$cd)) ) { 
            return 1; 
        }

        return 0;
    }

	function debug_to_console( $data ) {
		
		$output = '';
		
		if( is_array( $data ) ) {
            $output .= "console.warn( 'Debug Objects with Array.' ); console.log( '" . preg_replace("/\n/", "\\n", str_replace("'", "\'", var_export($data, TRUE))) . "' );";
		} 
        else if( is_object( $data ) ) {
			$data    = var_export( $data, TRUE );
			$data    = explode( "\n", $data );
			foreach( $data as $line ) {
				if( trim( $line ) ) {
					$line    = addslashes( $line );
					$output .= "console.log( '{$line}' );";
				}
			}
			$output = "<script>console.warn( 'Debug Objects with Object.' ); $output</script>";
		} 
        else {
			$output .= "<script>console.log( 'Debug Objects: {$data}' );</script>";
		}
		
		echo $output;
	}
    
    function rebuildVZStats() {
        $records = 0;
        
        // Quelldatenbank öffnen
        $source = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        // Pruefen ob die Datenbankverbindung hergestellt werden konnte
        if ($source->connect_errno == 0) {
            // Zieldatenbank öffnen
            $target = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);
            // Pruefen ob die Datenbankverbindung hergestellt werden konnte
            if ($target->connect_errno == 0) {
                // Alle Daten in der Zieltabelle löschen
                $target->query("DELETE FROM stats WHERE 1");
                // Zeitstempel von Heute
                $ts_today = (mktime(0,0,0)*1000);
                // (Tag der Inbetriebnahme der Solaranlage: 06.05.2015)
                // (Tag des Begins der Datenbankerfassung:  16.06.2015)
                $m = 6; $y = 2015;
                $ts_from = (mktime(0,0,0,$m,1,$y,0)*1000);
                $ts_to   = (mktime(0,0,0,$m+1,1,$y,0)*1000);
                
                while ($ts_from < $ts_today) {
                    // Monatsmaximum
                    $sql = "SELECT *
                            FROM data
                            WHERE channel_id = 20
                              AND timestamp >= ".$ts_from." 
                              AND timestamp < ".$ts_to."
                              ORDER BY value DESC
                              LIMIT 1";
                    
                    if ($res_source = $source->query($sql)) {
                        if ($row = $res_source->fetch_assoc()) {
                            $sql = "INSERT
                                    INTO stats (id, name, channel, timestamp, value)
                                    VALUES ( NULL, 'month_max', ".$row['channel_id'].", ".$row['timestamp'].", ".$row['value'].")";
                            $target->query($sql);
                            
                            $records = $records + 1;
                        }
                        $res_source->free();
                    }
                    
                    // Monatsertrag
                    $sql = "SELECT SUM(value) as sum
                            FROM data
                            WHERE channel = 28
                              AND timestamp >= ".$ts_from." 
                              AND timestamp < ".$ts_to;
                    
                    if ($res_target = $target->query($sql)) {
                        if ($row = $res_target->fetch_assoc()) {
                            $sql = "INSERT
                                    INTO stats (id, name, channel, timestamp, value)
                                    VALUES ( NULL, 'month_sum', 28, ".($ts_to - 1).", ".number_format($row['sum'], 3).")";
                            $target->query($sql);
                        }
                        $res_target->free();
                    }

                    $m = $m + 1;
                    if ($m > 12) {
                        $m = 1;
                        $y = $y + 1;
                    }
                    $ts_from = (mktime(0,0,0,$m,1,$y,0)*1000);
                    
                    if ($m == 12 )
                        $ts_to = (mktime(0,0,0,1,1,$y+1,0)*1000);
                    else
                        $ts_to = (mktime(0,0,0,$m+1,1,$y,0)*1000);
                } // while ($ts_from < $ts_today)
                
                $target->close();
            } //if ($target->connect_errno == 0)
            $source->close();
        } // if ($source->connect_errno == 0)
        
        echo "Anzahl Datensätze: <strong>".$records."</strong>";
    }

    function rebuildVZData() {
        $records = 0;
        
        // Quelldatenbank öffnen
        $source = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        // Pruefen ob die Datenbankverbindung hergestellt werden konnte
        if ($source->connect_errno == 0) {
            // Zieldatenbank öffnen
            $target = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);
            // Pruefen ob die Datenbankverbindung hergestellt werden konnte
            if ($target->connect_errno == 0) {
                // Alle Daten in der Zieldatenbank löschen
                $target->query("DELETE FROM data WHERE 1");
                
                // Weil die Datenerfassung erst mit Inbetriebnahme des
                // Raspberry Pi's begann, müssen die ersten Tageswerte
                // manuell nachgetragen werden.
                $a=array( 6.655, 4.638,  6.641, 6.078, 11.021,
                          8.382, 6.228, 10.320, 8.136,  9.770,
                          2.471, 7.014,  7.854, 5.763,  7.939,
                          7.339, 9.572,  4.959, 6.290,  2.082,
                          2.871, 4.844,  5.182, 4.608,  2.445,
                          5.286, 6.335,  4.666, 4.785, 10.347,
                          8.991, 4.993,  9.279, 7.710,  6.321,
                          7.606, 9.687,  8.199, 9.994,  7.120,
                          5.364 );
                          
                $ts = mktime(22,0,0,6,6,2015,0)*1000;
                
                for ($id=1; $id<=41; $id++) {
                    $sql = "INSERT
                            INTO data (id, channel, timestamp, value)
                            VALUES (".$id.", 28, ".$ts.", ".$a[$id-1].")";

                    $target->query($sql);
                    $records = $records + 1;

                    $ts = $ts + (24*60*60*1000);                    
                }
                
                // fehlenden Eintrag vom 16.06.2015 nachtragen
                $ts = mktime(22,0,0,6,16,2015,0)*1000;
                $sql = "INSERT
                        INTO data (id, channel, timestamp, value)
                        VALUES (".$id.", 28, ".$ts.", 5.715)";
                $target->query($sql);
                $id = $id + 1;
                $records = $records + 1;
                
                // Zeitstempel von Heute
                $ts_today = (mktime(0,0,0)*1000);
                
                // Frühest möglicher Datenbankzeitstempel
                // (Tag der Inbetriebnahme der Solaranlage: 06.05.2015)
                // (Tag des Begins der Datenbankerfassung:  16.06.2015)
                $ts_from = (mktime(0,0,0,6,16,2015,0)*1000);
                $ts_to   = $ts_from + (24*60*60*1000);
                               
                while ($ts_from < $ts_today) {
                    $sql = "SELECT *
                            FROM data
                            WHERE channel_id = 28
                              AND value > 0
                              AND timestamp >= ".$ts_from." 
                              AND timestamp < ".$ts_to."
                            ORDER BY value DESC
                            LIMIT 1";
                            
                    if ($res_source = $source->query($sql)) {
                        if ($row = $res_source->fetch_assoc()) {
                            $sql = "INSERT
                                    INTO data (id, channel, timestamp, value)
                                    VALUES (".$id.", ".$row['channel_id'].", ".$row['timestamp'].", ".$row['value'].")";
                            $target->query($sql);
                            $id = $id + 1;
                            $records = $records + 1;
                        }
                        $res_source->free();
                        
                        $ts_from = $ts_to;
                        $ts_to   = $ts_from + (24*60*60*1000);
                    }                    
                } // while ($ts_from < $ts_today)
                
                $target->close();
            } //if ($target->connect_errno == 0)
            $source->close();
        } // if ($source->connect_errno == 0)
        
        echo "Anzahl Datensätze: <strong>".$records."</strong>";
    }

	function getStatus() {
		$error        = '';
		$status       = '';
		$mode         = '';
		$log          = '';
		$fermentation = '';
		$sensor_1     = '';
		$sensor_2     = '';
		$target       = '';
		$ts_utc       = '0';
		$ts_local     = '0';
		
		$a = array();
		
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT item, value FROM config WHERE 1"; 
            if ($result = $mysqli->query($sql)) {
                while( $data = $result->fetch_array() ) {
                    switch( $data['item'] ) {
                        case 'state':
                            $status  = $data['value'];
                            break;
                        case 'mode':
                            $mode   = $data['value'];
                            break;
                        case 'log':
                            $log    = $data['value'];
                            break;
                        case 'target':
                        default:
                            // unknown config column
                    }
                }
                $result->free();
            }

            if( $status == 1 ) {
                $sql = "SELECT name FROM fermentations WHERE id = '".$log."'";
                if ($result = $mysqli->query($sql)) { 
                    if( ($row = $result->fetch_array()) ) {
                        $fermentation = $row['name'];
                    }
                    $result->free();
                }

                $sql = "SELECT *
                        FROM logs
                        WHERE fermentation = '".$log."'
                        ORDER BY timestamp DESC
                        LIMIT 1";
                if ($result = $mysqli->query($sql)) { 
                    if( ($row = $result->fetch_array()) ) {
                        $ts_utc   = $row['timestamp'];
                        $ts_local = $ts_utc + (date('Z') * 1000);
                    }
                    $result->free();

                    $sql = "SELECT *
                            FROM logs
                            WHERE fermentation = '".$log."'
                            AND timestamp = '".$ts_utc."'";
                    
                    if ($result = $mysqli->query($sql)) { 
                        while( $row = $result->fetch_array() ) {
                            switch( $row['sensor'] ) {
                                case '0':
                                    $target   = $row['temperature'];
                                    break;
                                case '1':
                                    $sensor_1 = $row['temperature'];
                                    break;
                                case '2':
                                    $sensor_2 = $row['temperature'];
                                    break;
                            }
                        }
                    }
                }
            }
          
            // close connection
            $mysqli->close();

			$a['status']       = $status;
			$a['mode']         = $mode;
			$a['log']          = $log;
			$a['fermentation'] = $fermentation;
			$a['s1']           = $sensor_1;
			$a['s2']           = $sensor_2;
			$a['target']       = $target;
        }
        else {
			$a['error'] = $mysqli->connect_error;
        }
		
		return $a;
	}

    function getAnalysisData( $year=-1 ) {
        $d_from     = ''; // start date
        $d_to       = ''; // end date
        $days       = ''; // number of days since implementation
        $from_evu   = ''; // kWh received from EVU
        $to_evu     = ''; // kWh delivered to EVU
        $from_evu_f = ''; // forecasted kWh from EVU
        $e_total    = ''; // total solar power produced
        $s_con      = ''; // consumed solar power (kWh)
        $ratio      = ''; // consumed solar power (ratio)
        $t_con      = ''; // total power consumption (EVU + solar)
        $tot_cf     = ''; // total consumption (forecast)
        $refund     = ''; // refund for delivery to EVU
        $savings    = ''; // savings due to consumed solar power
        $payoff     = ''; // sum of refund and savings
        
        // Datenbank-Objekt erzeugen
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        // Pruefen ob die Datenbankverbindung hergestellt werden konnte
        if ($mysqli->connect_errno == 0) {
            if ($year == -1) {
                $year  = date("Y");
                $month = date("j");
                $day   = date("n");
            }
            
             // start date
            if ($year == 2015) {
                $from = date( "06.05.2015" );
            }
            else {
                $from = date( "01.01.".$year );
            }
            
            // end date
            if ($year == date("Y")) {
                $to = date("d.m.Y");
            }
            else {
                $to = date( "31.12.".$year );
            }
			
			$dateFrom = new DateTime($from);
			$dateTo   = new DateTime($to);
			$d_from   = $dateFrom->format("d.m.Y");
			$d_to     = $dateTo->format("d.m.Y");
			$days     = $dateFrom->diff($dateTo)->days;
			
			if ($days == 0) {
				$days = 1;
			}
			
            $ts_from = (mktime(0,0,0,1,1,$year,0)*1000);
            $ts_to = (mktime(0,0,0,$month,$day,$year,0)*1000);
           
            // from EVU
            $from_evu_old = 0;
            $sql = "SELECT * 
                    FROM data 
                    WHERE channel_id = 29 
                      AND timestamp >= ".$ts_from."
                    ORDER BY timestamp ASC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                $row = $result->fetch_assoc();
                $from_evu_old = $row['value'];
                $result->free();
            }
            
            $sql = "SELECT * FROM data WHERE channel_id = 29 ORDER BY timestamp DESC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                $row = $result->fetch_assoc();
                $from_evu_act = $row['value'];
                $result->free();
            }
            $from_evu = $from_evu_act - $from_evu_old;
            
            // to EVU
            $to_evu_old = 0;
            $sql = "SELECT * 
                    FROM data 
                    WHERE channel_id = 30
                      AND timestamp < ".$ts_from."
                    ORDER BY timestamp DESC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                $row = $result->fetch_assoc();
                $to_evu_old = $row['value'];
                $result->free();
            }
            
            $sql = "SELECT * FROM data WHERE channel_id = 30 ORDER BY timestamp DESC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                $row = $result->fetch_assoc();
                $to_evu_act = $row['value'];
                $result->free();
            }
            $to_evu = $to_evu_act - $to_evu_old;
            
            // total solar power produced
            $e_total_old = 0;
            $sql = "SELECT * 
                    FROM data 
                    WHERE channel_id = 26 
                      AND timestamp < ".$ts_from."
                    ORDER BY timestamp DESC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                $row = $result->fetch_assoc();
                $e_total_old = $row['value'];
                $result->free();
            }
            
            $sql = "SELECT * FROM data WHERE channel_id = 26 ORDER BY timestamp DESC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                $row = $result->fetch_assoc();
                $e_total_act = $row['value'];
                $result->free();
            }
            $e_total = $e_total_act - $e_total_old;
            
            // solar power consumed (kWh)
            $s_con = ($e_total - $to_evu);
            
            // solar power consumed (ratio)
            $ratio = ($s_con * 100 / $e_total);
            
            // total power consumed
            $t_con = ($from_evu + $s_con);
            
            // total power consumption forecast
            $tot_cf = (($from_evu + $s_con) / $days * 365);

            // from EVU forecast
            $from_evu_f = ($tot_cf - (1400*0.64));
            
            // refund of kWh supplied to EVU
            $refund = ($to_evu * 0.1243);

            // savings due to consumption of solar power
            $savings = ($s_con * 0.27);

            // total pay-off
            $payoff = ($refund + $savings);

            // Datenbankverbindung schliessen
            $mysqli->close();
        }
        else {
            // Fehler beim Aufbau der Verbindung zu Datenbank
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
        $response = array (
            "from"      => "$d_from",
            "to"        => "$d_to",
            "days"      => "$days",
            "from_evu"  => "$from_evu",
            "to_evu"    => "$to_evu",
            "evu_fore"  => "$from_evu_f",
            "e_total"   => "$e_total",
            "s_con"     => "$s_con",
            "ratio"     => "$ratio",
            "t_con"     => "$t_con",
            "tot_cf"    => "$tot_cf",
            "refund"    => "$refund",
            "savings"   => "$savings",
            "payoff"    => "$payoff"
        );

        return $response;
    }
    
    function getSolarOutput( $year=-1 ) {
        $r = array (
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
          -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1
        );
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            if ($year == -1) {
                $year = date( "Y" );
            }
            
            $ts_from = (mktime(0,0,0,1,1,$year,0)*1000);
            $ts_to = (mktime(0,0,0,12,31,$year,0)*1000);
           
            $sql = "SELECT timestamp, value 
                    FROM data 
                    WHERE channel = 28 
                      AND timestamp >= ".$ts_from." 
                      AND timestamp < ".$ts_to." 
                    ORDER BY timestamp ASC";
            
            if ($result = $mysqli->query($sql)) { 
                while ($row = $result->fetch_array()) {
                    $m = date( "n", ($row['timestamp']/1000));                
                    $d = date( "j", ($row['timestamp']/1000));
                    $i = (($m-1)*31)+($d-1);
                    if ($r[$i] < $row['value']) {
                        $r[$i] = $row['value'];
                    }
                }
                $result->free();
            }            
            // close connection
            $mysqli->close();

            // create database object
            $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
            // check if connection is established
            if ($mysqli->connect_errno == 0) {
                $sql = "SELECT * 
                        FROM data 
                        WHERE channel_id = 28 AND value > 0
                        ORDER BY timestamp DESC LIMIT 1";
                if ($result = $mysqli->query($sql)) {
                    if ($row = $result->fetch_assoc()) {
                        $m = date( "n", ($row['timestamp']/1000));                
                        $d = date( "j", ($row['timestamp']/1000));
                        if( $row['value'] > $r[(($m-1)*31)+($d-1)] ) {
                            $r[(($m-1)*31)+($d-1)] = $row['value'];
                        }
                    }
                    $result->free();
                }                    
                // close connection
                $mysqli->close();
            }
            else {
                // error: connecting to database
                echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
            }
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
        return json_encode($r);
    }

    function getSolarValues( $y, $m, $d ) {
        $e_today   = '';
        $e_total   = '';
        $from_evu  = '';
        $to_evu    = '';
        $own_c     = '';
        $ratio     = '';
        $max_value = '';
        $max_time  = '';
        
        $ts = strtotime($y."/".$m."/".$d);
        $start = $ts*1000;
        $stop = $start + (24*60*60*1000) - 1;
        
        // create database object
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            
            // today's production
            $sql = "SELECT MAX(value) as value 
                    FROM data 
                    WHERE channel_id = 28                    
                      AND timestamp >= ".$start." 
                      AND timestamp <= ".$stop;
            
            if ($result = $mysqli->query($sql)) {   
                if ($row = $result->fetch_assoc()) {
                    $e_today = $row['value'];
                }
                $result->free();
            }
            
            // this year total production
            $ts_start = strtotime((intval($y)-1)."/12/31 23:59:59")*1000;
            
            $start_value = 0;
            $sql = "SELECT * FROM data 
                    WHERE channel_id = 26 AND timestamp > ".$ts_start." 
                    ORDER BY timestamp ASC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {   
                if ($row = $result->fetch_assoc()) {
                    $start_value = $row['value'];
                }
                $result->free();
            }
 
            $sql = "SELECT * FROM data 
                    WHERE channel_id = 26 AND timestamp <= ".$stop." 
                    ORDER BY timestamp DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {   
                if ($row = $result->fetch_assoc()) {
                    $e_total = $row['value'] - $start_value;
                }
                $result->free();
            }

            // this year total import
            $start_value = 0;
                        
            $sql = "SELECT * FROM data 
                    WHERE channel_id = 29 AND timestamp > ".$ts_start." 
                    ORDER BY timestamp ASC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {   
                if ($row = $result->fetch_assoc()) {
                    $start_value = $row['value'];
                }
                $result->free();
            }
                        
            $sql = "SELECT * FROM data 
                    WHERE channel_id = 29 AND timestamp <= ".$stop." 
                    ORDER BY timestamp DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {   
                if ($row = $result->fetch_assoc()) {
                    $from_evu = $row['value'] - $start_value;
                }
                $result->free();
            }

            // this year total export
            $start_value = 0;
                        
            $sql = "SELECT * FROM data 
                    WHERE channel_id = 30 AND timestamp > ".$ts_start." 
                    ORDER BY timestamp ASC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {   
                if ($row = $result->fetch_assoc()) {
                    $start_value = $row['value'];
                }
                $result->free();
            }
            
            $sql = "SELECT * FROM data 
                    WHERE channel_id = 30 AND timestamp <= ".$stop." 
                    ORDER BY timestamp DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {   
                if ($row = $result->fetch_assoc()) {
                    $to_evu = $row['value'] - $start_value;
                }
                $result->free();
            }

            // Tagesmaximum
            $y = date("Y");
            $m = date("n");
            $d = date("j");
            
            $ts_from = (mktime(0,0,0,$m,$d,$y,0)*1000);
            $ts_to = $ts_from + (24*60*60*1000);

            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 20
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER by value DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $max_value = $row['value'];
                    $max_time  = date("H:i", (intval($row['timestamp'] / 1000)));
                }
                $result->free();
            }
            
            // close connection
            $mysqli->close();

            $own_c = $e_total - $to_evu;
            $ratio = $own_c * 100 / $e_total;
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        $e_today  = number_format( $e_today, 2, ',', '.');
        $e_total  = number_format( $e_total, 2, ',', '.');
        $from_evu = number_format( $from_evu, 2, ',', '.');
        $to_evu   = number_format( $to_evu, 2, ',', '.');
        $own_c    = number_format( $own_c, 2, ',', '.');
        $ratio    = number_format( $ratio, 2, ',', '.');

        $response = array (
            "e_today"     => "$e_today",
            "e_total"     => "$e_total",
            "from_evu"    => "$from_evu",
            "to_evu"      => "$to_evu",
            "consumption" => "$own_c",
            "ratio"       => "$ratio",
            "max_value"   => "$max_value",
            "max_time"    => "$max_time"
        );

        return $response;
    }

    function openPage( $url ) {
        $h = fopen($url, 'r');
        $c = fread($h, filesize($url));
        fclose($h);
        
        return $c;
    }
    
	function getContent( $p ) {
        $content_pages = 'pages';
        
		$path = $content_pages.'/'.$p.'php';
        if (file_exists($path)) {
            return openPage($path);
        } else {
            return openPage($content_pages.'/404.html');
        }
    }
    
    function getDescription( $channel ) {
        $description = '';
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_MCP3008);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT * FROM channels WHERE id = ".$channel;
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                    $description = $row['desc'];
                }
                $result->free();
            }            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        return $description;
    }

    function getData( $ch ) {
        $r = '';
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_MCP3008);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT * FROM data WHERE channel = ".$ch." ORDER BY timestamp DESC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                    $r = $row['value'];
                }
                $result->free();
            }            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        return $r;
    }

    function getCurrentSensorValue( $column ) {
        $r = '';
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_BMP180);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT * FROM data WHERE 1 ORDER BY timestamp DESC LIMIT 1";
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                    if ($column == 'temperature') {
                        $r = number_format($row[$column], 1, ",", ".");
                    }
                    else {
                        $r = number_format($row[$column], 0, ",", ".");
                    }
                }
                $result->free();
            }            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        return $r;
        return $r;
    }
	
    function getAltitude() {
        $r = '';
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_BMP180);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT * FROM config WHERE item = 'altitude'";
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                    $r = $row['value'];
                }
                $result->free();
            }            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        return $r;
    }

    function saveProductionValue( $d, $v ) {
				
		if (!empty($d) && ($v >= 0) ) {
			$ts = strtotime($d."23:59:59")*1000;
			
			// create database object
			$mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);

			// check if connection is established
			if ($mysqli->connect_errno == 0) {
                $sql = "SELECT id, value
                        FROM data 
                        WHERE channel = 28 
                          AND timestamp = ".$ts; 
				
				$id = 0;
                if ($result = $mysqli->query($sql)) { 
                    if ($row = $result->fetch_assoc()) {
						$id = $row['id'];
                    }
				
                    $result->free();
                }
				
				if ($id > 0) {
					$sql = "UPDATE data
					        SET value = '".$v."'
							WHERE id = '".$id."'";
				}
				else {
					$sql = "INSERT
							INTO data (channel, timestamp, value)
							VALUES (28, ".$ts.", ".$v.")";
				}
				
				$mysqli->query($sql);
				
				$dp = date_parse($d);
				$m = $dp[month];
				$y = $dp[year];
				
                $ts_from = (mktime(0,0,0,$m,1,$y,0)*1000);
				if ($m == 12) {
					$ts_to = (mktime(0,0,0,1,1,$y+1,0)*1000);
				}
				else {
					$ts_to = (mktime(0,0,0,$m+1,1,$y,0)*1000);
				}
				
				$mysqli->close();
			}
		}
		
        return 0;
    }

    function setThreshold( $i, $v ) {
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_MCP3008);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "UPDATE config SET value = '".$v."' WHERE item = '".$i."'";
            $mysqli->query($sql);
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
        return 1;
    }

    function getThreshold( $item='dawn' ) {
        $r = '';
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_MCP3008);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT * FROM config WHERE item = '".$item."'";
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                    $r = $row['value'];
                }

                $result->free();
            }            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        return $r;
    }

    function delLastChar( $string="" )
    {
        $t = substr($string, 0, -1);
        return($t);
    }

    function getSensorValues( $database, $table, $column, $timePeriodInHours=96 ) {
        $chartValues = '';
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, $database);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT UNIX_TIMESTAMP(timestamp) AS time, ".$column."
                    FROM ".$table." 
                    WHERE timestamp >= DATE_SUB(NOW(), INTERVAL ".$timePeriodInHours." HOUR) AND timestamp <= NOW() 
                    ORDER BY timestamp ASC"; 
            if ($result = $mysqli->query($sql)) {
                while($r_data = $result->fetch_array()) {
                    $v ='';
                    
                    if ($column == 'temperature') {
                        $v = round($r_data[$column], 1);
                    }
                    else {
                        $v = round($r_data[$column], 2);
                    }
                    
                    $t = $r_data['time']*1000;                  // mysql-timestamp to milliseconds
                    if( date('I') == 0 ) {
                        $t += 1*60*60*1000;                     // GMT+1 (Berlin/Germany - normal time)
                    } else {
                        $t += 2*60*60*1000;                     // GMT+2 (Berlin/Germany - summer time)
                    }
                    $chartValues .= '[';
                    $chartValues .= $t.',';
                    $chartValues .= $v;
                    $chartValues .= '],';
                }
                        
                $chartValues = delLastChar($chartValues);        // Komma hinter dem letzten Temperaturwert entfernen
                $result->free();
            }
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
        return $chartValues;
    }

    function getChartValues( $sensorID=0, $timePeriodInHours=24 ) {
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_MCP3008);
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            $sql = "SELECT timestamp, value 
                    FROM data
                    WHERE channel = ".$sensorID." AND timestamp >= date_sub(now(), interval ".$timePeriodInHours." hour) AND timestamp <= now() 
                    GROUP BY DATE_FORMAT(timestamp, '%Y-%m-%d %H:%i') 
                    ORDER BY timestamp ASC"; 
            if ($result = $mysqli->query($sql)) {
                $chartValues = '';

                while($r_data = $result->fetch_array()) {
                        $v = $r_data['value'];                      // Wert
                        
                        $t = strtotime($r_data['timestamp'])*1000;  // mysql-timestamp to milliseconds
                        if( date('I') == 0 ) {
                            $t += 1*60*60*1000;                     // GMT+1 (Berlin/Germany - normal time)
                        } else {
                            $t += 2*60*60*1000;                     // GMT+2 (Berlin/Germany - summer time)
                        }
                        
                        $chartValues .= '[';
                        $chartValues .= $t.',';
                        $chartValues .= $v;
                        $chartValues .= '],';
                }

                $chartValues = delLastChar($chartValues);        // Komma hinter dem letzten Temperaturwert entfernen
                $result->free();
            }            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
        return $chartValues;
    }

    function utcTimestamp() {
		
		$state  = 0;
		$mode   = 0;
		$log    = 0;
		$ts_utc = '0';
		
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
		
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
			// check state
            $sql = "SELECT * FROM config WHERE item = 'state'";
            if ($result = $mysqli->query($sql)) {
				if ($row = $result->fetch_array()) {
					$state = $row['value'];
				}
			}
			
			if ($state == 1) {
				//check mode
				$sql = "SELECT * FROM config WHERE item = 'mode'";
				if ($result = $mysqli->query($sql)) {
					if ($row = $result->fetch_array()) {
						$mode = $row['value'];
					}
				}
				
				switch ($mode) {
					case 0:
						$log = 0;
						break;					
					default:
						$sql = "SELECT * FROM config WHERE item = 'log'";
						if ($result = $mysqli->query($sql)) {
							if ($row = $result->fetch_array()) {
								$log = $row['value'];
							}
						}
				}
				
				$sql = "SELECT timestamp
						  FROM logs
						 WHERE fermentation = '".$log."'
						   AND sensor = '1'
						 ORDER BY timestamp DESC
						 LIMIT 1";
				
				if ($result = $mysqli->query($sql)) {
					if ($row = $result->fetch_array()) {
						$ts_utc = $row['timestamp'];
					}
				}
			}
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            $error = "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
		
		return $ts_utc;
    }

    function getTemperatureChartValues( $sensor ) {
		
		$state  = 0;
		$mode   = 0;
		$log    = 0;
        $values = '';
		
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
		
        // check if connection is established
        if ($mysqli->connect_errno == 0) {
			// check state
            $sql = "SELECT * FROM config WHERE item = 'state'";
            if ($result = $mysqli->query($sql)) {
				if ($row = $result->fetch_array()) {
					$state = $row['value'];
				}
			}
			
			if ($state == 1) {
				//check mode
				$sql = "SELECT * FROM config WHERE item = 'mode'";
				if ($result = $mysqli->query($sql)) {
					if ($row = $result->fetch_array()) {
						$mode = $row['value'];
					}
				}
				
				switch ($mode) {
					case 0:
						$log = 0;
						break;					
					default:
						$sql = "SELECT * FROM config WHERE item = 'log'";
						if ($result = $mysqli->query($sql)) {
							if ($row = $result->fetch_array()) {
								$log = $row['value'];
							}
						}
				}

				$sql = "SELECT timestamp, temperature 
						  FROM logs
						 WHERE fermentation = '".$log."'
						   AND sensor = '".$sensor."'
						 ORDER BY timestamp ASC";
				
				if ($result = $mysqli->query($sql)) {
					while ($row = $result->fetch_array()) {
						$ts_utc = $row['timestamp'];
						$ts     = $ts_utc + (date('Z') * 1000);
						
						$values .= '[';
						$values .= $ts.',';
						$values .= $row['temperature'];
						$values .= '],';
					}

					$values = delLastChar($values);
					$result->free();
				}
			}
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            $values = "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
		
		return $values;
    }

    function getMonthValues( $year=0 ) {
        // return value
        $r = array ();

        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);

        // check if connection is established
        if ($mysqli->connect_errno == 0) {

            // if no year is given, we use the current year
            if ($year == 0) {
                $year = date( "Y" );
            }
            
            // read sum for each month from database
            for( $i=1; $i<=12; $i++ ) {
                $ts_from = (mktime(0,0,0,$i,1,$year,0)*1000);
                $ts_to   = (mktime(0,0,0,$i+1,1,$year,0)*1000)-1;
           
                $sql = "SELECT SUM(value) as value 
                        FROM data 
                        WHERE channel = 28 
                          AND timestamp >= ".$ts_from." 
                          AND timestamp <= ".$ts_to;
                
                if ($result = $mysqli->query($sql)) { 
                    while ($row = $result->fetch_assoc()) {
                        $r[$i] = sprintf( "%.3f", $row['value']);
                    }
                    
                    $result->free();
                }
            }
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
        return $r;
    }

    function getTimeDifference( $a, $b ) {

        $start = explode(":", $a);
        $stop  = explode(":", $b);
        
        $minutes_1 = ($start[0]*60) + $start[1];
        $minutes_2 = ($stop[0]*60)  + $stop[1];
        
        return $minutes_2 - $minutes_1;
    }
    
    function dayProduction( $y, $m, $d ) {
        $production = 0.0;
        $timestamp  = 0;
           
        // create database object
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        
        if ($mysqli->connect_errno == 0) {
            $ts_from = (mktime(0,0,0,$m,$d,$y,0)*1000);
            $ts_to = $ts_from + (24*60*60*1000);

            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 28 
                      AND timestamp >= ".$ts_from."
                      AND timestamp < ".$ts_to;
            
            if ($result = $mysqli->query($sql)) { 
                while ($row = $result->fetch_array()) {
                    if ($row['value'] > $production) {
                        $production = $row['value'];
                        $timestamp ^= $row['timestamp'];
                    }
                }
                $result->free();
            }

            // close connection
            $mysqli->close();
        }
        
        return $production;
    }
    
    function dayMaximum( $y, $m, $d ) {
        $r = 0;
        
        // create database object
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);

        if ($mysqli->connect_errno == 0) {
            $ts_from = (mktime(0,0,0,$m,$d,$y,0)*1000);
            $ts_to = $ts_from + (24*60*60*1000);

            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 20
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER by value DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $r = $row['value'];
                }
                $result->free();
            }
            
            // close connection
            $mysqli->close();
        }
                    
        return $r;
    }
    
    function dayAnalysis( $y, $m, $d ) {
        $r = array ('0.00','0.00',      // Tagesertrag IST (kWh/kWp), Tagesertrag SOLL (kWh/kWp)
                    '0.00','0.00',      // Abweichung zu SOLL (kWh/kWp), Abweichung zu SOLL (%)
                    '0.00','00:00',     // Ertrag (kWh), Ertrag (Uhrzeit)
                    '0.00','00:00',     // Tagesmaximum (W), Tagesmaximum (Uhrzeit)
                    '00:00','00:00',    // Betriebszeit VON (Uhrzeit), Betriebszeit BIS (Uhrzeit)
                    '0','0');           // Betriebsdauer (Std.), Betriebsdauer (Min.)

        // create database object
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);

        if ($mysqli->connect_errno == 0) {
            // Tagesertrag
            $ts_from = (mktime(0,0,0,$m,$d,$y,0)*1000);
            $ts_to = $ts_from + (24*60*60*1000);

            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 28 
                      AND timestamp >= ".$ts_from."
                      AND timestamp < ".$ts_to;
            
            $ertrag    = 0.0;
            $timestamp = 0;
            
            if ($result = $mysqli->query($sql)) { 
                while ($row = $result->fetch_array()) {
                    if ($row['value'] > $ertrag) {
                        $ertrag    = $row['value'];
                        $timestamp = $row['timestamp'];
                    }
                }
                $result->free();
            }
            // Ertrag: Ist (kWh/kWp)
            $r[0] = sprintf( "%.2f kWh/kWp", $ertrag/1.7);
            // Ertrag: Soll (kWh/kWp)
            $r[1] = sprintf( "%.2f kWh/kWp", dayTarget($y, $m)/1.7);
            // Abw. zu Soll (kWh/kWp)
            $r[2] = sprintf( "%.2f kWh/kWp", $r[0]-$r[1]);
            // Abw. zu Soll (Ratio)
            $r[3] = sprintf( "%.2f %%", 100-($r[0]*100/$r[1]));
            // Ertrag: (kWh)
            $r[4] = sprintf( "%.2f kWh", $ertrag);
            // Ertrag: (Uhrzeit)
            $r[5] = sprintf( "%s Uhr", date( 'H:i', $timestamp/1000 ) );
            
            // Tagesmaximum
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 20
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER by value DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    // Maximum: (W)
                    $r[6] = sprintf( "%d W", $row['value'] );
                    // Maximum: (Uhrzeit)
                    $r[7] = sprintf( "%s Uhr", date( 'H:i', $row['timestamp']/1000 ) );
                }
                $result->free();
            }
            
            // Betriebszeit
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 20
                      AND value > 0
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER by timestamp ASC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    // Betriebszeit: (von)
                    $r[8] = sprintf( "%s Uhr", date( 'H:i', $row['timestamp']/1000 ) );
                }
                $result->free();
            }

            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 20
                      AND value > 0
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER by timestamp DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    // Betriebszeit: (bis)
                    $r[9] = sprintf( "%s Uhr", date( 'H:i', $row['timestamp']/1000 ) );
                }
                $result->free();
            }            
            
            $delta = getTimeDifference( $r[8], $r[9] );
            // Betriebsdauer: (Std.)
            $r[10] = sprintf( "%d Std.", $delta/60 );
            // Betriebsdauer: (Min.)
            $r[11] = sprintf( "%d Min.", $delta%60 );
            
            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
      
        return $r;
    }

    function monthAnalysis( $y, $m, $d, $d_ertrag, $d_maximum ) {
        $r = array ('0.00','0.00',          // Ertrag: Ist (kWh/kWp), Ertrag: Soll (kWh/kWp)
                    '0.00','0.00',          // Abw. zu Soll (kWh/kWp), Abw. zu Soll (%)
                    '0.00','0.0.0000',      // Ertrag: (kWh), Ertrag: (Datum)
                    '0.00','0.0.0000',      // Maximum: (W), Maximum: (Datum)
                    '0','0',                // Durchschnitt: Ist (kWh/kWp), Durchschnitt: Ist (kWh/kWp)
                    '0', '0');              // Vergütung: (kWh), Vergütung: (€)
        
        $ts_from = (mktime(0,0,0,$m,1,$y,0)*1000);
        $ts_to = (mktime(0,0,0,$m+1,1,$y,0)*1000) - 1;
        
        // create database object (local)
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);
        if ($mysqli->connect_errno == 0) {
            // Monatsertrag ermitteln
            $sql = "SELECT SUM(value) as value
                    FROM data 
                    WHERE channel = 28 
                      AND timestamp >= ".$ts_from."
                      AND timestamp < ".$ts_to;
            
            $ertrag = 0.0;
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                       $ertrag = $row['value'];
                }
                $result->free();
            }

            // letzten timestamp ermitteln
            $sql = "SELECT timestamp
                    FROM data 
                    WHERE channel = 28 
                      AND timestamp >= ".$ts_from."
                      AND timestamp < ".$ts_to."
                    ORDER BY timestamp DESC
                    LIMIT 1";
            
            $timestamp = 0;            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $timestamp = $row['timestamp'];
                }
                $result->free();
            }
                        
            $d_today = date("j");
            $m_today = date("n");
            $y_today = date("Y");
            
            if (($y_today == $y) && ($m_today == $m)) {
                if ($d_today == $d) {
                    $ertrag = $ertrag + $d_ertrag;
                }
                else {
                    $ertrag = $ertrag + dayProduction($y_today, $m_today, $d_today);
                }
            }

            // Ertrag: Ist (kWh/kWp)
            $r[0] = sprintf( "%.2f kWh/kWp", $ertrag/1.7);
            // Ertrag: Soll (kWh/kWp)
            $r[1] = sprintf( "%.2f kWh/kWp", monthTarget($y, $m, $d)/1.7);
            // Abw. zu Soll (kWh/kWp)
            $r[2] = sprintf( "%.2f kWh/kWp", $r[0]-$r[1]);
            // Abw. zu Soll (Ratio)
            $r[3] = sprintf( "%.2f %%", 100-($r[0]*100/$r[1]));
            // Ertrag: (kWh)
            $r[4] = sprintf( "%.2f kWh", $ertrag);
            // Ertrag: (Datum)
            $r[5] = sprintf( "%02d.%02d.%d", $d_today, $m_today, $y_today);
            
            // Monatsmaximum (bis gestern)
            $sql = "SELECT timestamp, value
                    FROM stats 
                    WHERE channel = 20
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $max_value = sprintf( "%d W", $row['value'] );
                    $max_date = sprintf( "%s", date( 'd.m.Y', $row['timestamp']/1000 ) );
                }
                $result->free();
            }
            
            // close connection
            $mysqli->close();

            if (($y_today == $y) && ($m_today == $m)) {
                if ($d_today != $d) {
                    $d_maximum = dayMaximum($y_today, $m_today, $d_today);
                }
                
                if ($d_maximum >= $max_value) {
                    $max_value = $d_maximum;
                    $max_date  = sprintf( "%02d.%02d.%d", $d_today, $m_today, $y_today );
                }
            }

            // Maximum: (W)
            $r[6] = $max_value;
            // Maximum: (Datum)
            $r[7] = $max_date;
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        // create database object (volkszaehler)
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        if ($mysqli->connect_errno == 0) {
            // Abgabe an den Energieversorger
            $to_evu = 0;
            $to_evu_1 = 0;
            $to_evu_2 = 0;
            
            $sql = "SELECT value
                    FROM data 
                    WHERE channel_id = 17
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER by timestamp ASC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $to_evu_1 = $row['value'];
               }
                $result->free();
            }
            
            $sql = "SELECT value
                    FROM data 
                    WHERE channel_id = 17
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER by timestamp DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $to_evu_2 = $row['value'];
               }
                $result->free();
            }

            $to_evu = $to_evu_2 - $to_evu_1;            
            
            // close connection
            $mysqli->close();
        }     
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
        
        if( ($y == date( 'Y' )) && ($m == date( 'n' )) )
            $d = (date( 'j' ) - 1);
        else
            $d = cal_days_in_month(CAL_GREGORIAN,$m,$y);
        
        // Durchschnitt (Ist)
        $r[8] = sprintf( "%.2f kWh/kWp", ($r[0] / $d) );
        // Durchschnitt (Soll)
        $r[9] = sprintf( "%.2f kWh/kWp", ($r[1] / $d) );
        // Vergütung: kWh
        $r[10] = sprintf( "%.2f kWh", $to_evu );
        // Vergütung: €
        $r[11] = sprintf( "%.2f €", $to_evu * feedCompensation($y, $m, 1) );
        
        return $r;
    }

    function getMeterReadings( $year ) {
        $r = array ('0.00','00.00.0000 00:00',    // ACE3000 Import:  Zählerstand (alt), Timestamp
                    '0.00','00.00.0000 00:00',    // ACE3000 Import:  Zählerstand (neu), Timestamp
					'0.00','00.00.0000 00:00',    // ACE3000 Import:  Import, Timestamp
					'0.00','00.00.0000 00:00',    // ACE3000 Export:  Zählerstand (alt), Timestamp
                    '0.00','00.00.0000 00:00',    // ACE3000 Export:  Zählerstand (neu), Timestamp
					'0.00','00.00.0000 00:00',    // ACE3000 Export:  Import, Timestamp
                    '0.00','00.00.0000 00:00',    // SB1600TL:        Zählerstand (alt), Timestamp
					'0.00','00.00.0000 00:00',    // SB1600TL:        Zählerstand (neu), Timestamp
					'0.00','00.00.0000 00:00');   // SB1600TL:        Produktion, Timestamp

        // generate sql from/to timestamps
        $ts_from = (mktime(0,0,0,1,1,$year,0)*1000);
        $ts_to   = (mktime(0,0,0,1,1,$year+1,0)*1000);

        // create database object (local)
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        if ($mysqli->connect_errno == 0) {
            // db connection established

            // ACE3000 - Import: Startwert ermitteln
            $start_v = 0.0;
			$start_t = 0;
			
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 29 
                      AND timestamp >= ".$ts_from."
                    ORDER BY timestamp ASC
					LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                       $start_t = $row['timestamp'];
					   $start_v = $row['value'];
                }
                $result->free();
            }
            
            // ACE3000 - Import: Aktuellen Zählerstand ermitteln
            $act_v = 0.0;
			$act_t = 0;
			
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 29 
                      AND timestamp < ".$ts_to."
                    ORDER BY timestamp DESC
					LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                       $act_t = $row['timestamp'];
					   $act_v = $row['value'];
                }
                $result->free();
            }
			
			// ACE3000 - Import: Jahresverbrauch ermitteln
            $con_v = $act_v - $start_v;
			$con_t = $act_t;
			
            // ACE3000 - Import:
            $r[0] = sprintf( "%.1f", $start_v);
			$r[1] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $start_t/1000 ) );
			$r[2] = sprintf( "%.1f", $act_v);
			$r[3] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $act_t/1000 ) );
			$r[4] = sprintf( "%.1f", $con_v);
			$r[5] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $con_t/1000 ) );

            // ACE3000 - Export: Startwert ermitteln
            $start_v = 0.0;
			$start_t = 0;
			
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 30 
                      AND timestamp >= ".$ts_from."
                    ORDER BY timestamp ASC
					LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                       $start_t = $row['timestamp'];
					   $start_v = $row['value'];
                }
                $result->free();
            }
            
            // ACE3000 - Export: Aktuellen Zählerstand ermitteln
            $act_v = 0.0;
			$act_t = 0;
			
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 30 
                      AND timestamp < ".$ts_to."
                    ORDER BY timestamp DESC
					LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                       $act_t = $row['timestamp'];
					   $act_v = $row['value'];
                }
                $result->free();
            }
			
			// ACE3000 - Export: Jahresverbrauch ermitteln
            $con_v = $act_v - $start_v;
			$con_t = $act_t;
			
            // ACE3000 - Export:
            $r[6] = sprintf( "%.1f", $start_v);
			$r[7] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $start_t/1000 ) );
			$r[8] = sprintf( "%.1f", $act_v);
			$r[9] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $act_t/1000 ) );
			$r[10] = sprintf( "%.1f", $con_v);
			$r[11] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $con_t/1000 ) );
			
            // SB1600TL - Solarstrom: Startwert ermitteln
            $start_v = 0.0;
			$start_t = 0;
			
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 26 
                      AND timestamp >= ".$ts_from."
                    ORDER BY timestamp ASC
					LIMIT 1";
            
            if ($result = $mysqli->query($sql)) {
                if ($row = $result->fetch_assoc()) {
                       $start_t = $row['timestamp'];
					   $start_v = $row['value'];
                }
                $result->free();
            }
            
            // SB1600TL - Solarstrom: Aktuellen Zählerstand ermitteln
            $act_v = 0.0;
			$act_t = 0;
			
            $sql = "SELECT timestamp, value
                    FROM data 
                    WHERE channel_id = 26 
                      AND timestamp < ".$ts_to."
                    ORDER BY timestamp DESC
					LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                       $act_t = $row['timestamp'];
					   $act_v = $row['value'];
                }
                $result->free();
            }
			
			// SB1600TL - Solarstrom: Jahresproduktion ermitteln
            $con_v = $act_v - $start_v;
			$con_t = $act_t;
			
            // SB1600TL - Solarstrom:
            $r[12] = sprintf( "%.1f", $start_v);
			$r[13] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $start_t/1000 ) );
			$r[14] = sprintf( "%.1f", $act_v);
			$r[15] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $act_t/1000 ) );
			$r[16] = sprintf( "%.1f", $con_v);
			$r[17] = sprintf( "%s Uhr", date( 'd.m.Y H:i', $con_t/1000 ) );
			
            // close connection
            $mysqli->close();
		}
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
         
        return $r;
    }


    function yearAnalysis( $y, $m, $d, $d_ertrag, $d_maximum ) {
        $r = array ('0.00','0.00',          // Ertrag: Ist (kWh/kWp), Ertrag: Soll (kWh/kWp)
                    '0.00','0.00',          // Abw. zu Soll (kWh/kWp), Abw. zu Soll (%)
                    '0.00','0.0.0000',      // Ertrag: (kWh), Ertrag: (Datum)
                    '0.00','0.0.0000',      // Maximum: (W), Maximum: (Datum)
                    '0','0',                // Durchschnitt: Ist (kWh/kWp), Durchschnitt: Soll (kWh/kWp)
                    '0', '0');              // Vergütung: (kWh), Vergütung: (€)

        if ($y != date('Y'))
            $m = 12;
        else
            $m = date('n');
        
        // generate sql from/to timestamps
        $ts_from = (mktime(0,0,0,1,1,$y,0)*1000);
        $ts_to   = (mktime(0,0,0,1,1,$y+1,0)*1000);

        // create database object (local)
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);
        if ($mysqli->connect_errno == 0) {
            // db connection established

            // Jahresertrag ermitteln
            $sql = "SELECT SUM(value) as value
                    FROM data 
                    WHERE channel = 28 
                      AND timestamp >= ".$ts_from."
                      AND timestamp < ".$ts_to;
            
            $ertrag = 0.0;
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                       $ertrag = $row['value'];
                }
                $result->free();
            }
            
            // letzten timestamp ermitteln
            $sql = "SELECT timestamp
                    FROM data 
                    WHERE channel = 28 
                      AND timestamp >= ".$ts_from."
                      AND timestamp < ".$ts_to."
                    ORDER BY timestamp DESC
                    LIMIT 1";
            
            $timestamp = 0;            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $timestamp = $row['timestamp'];
                }
                $result->free();
            }

            $d_today = date("j");
            $m_today = date("n");
            $y_today = date("Y");
            
            if (($y_today == $y) && ($m_today == $m)) {
                if ($d_today == $d) {
                    $ertrag = $ertrag + $d_ertrag;
                }
                else {
                    $ertrag = $ertrag + dayProduction($y_today, $m_today, $d_today);
                }
            }

            // Ertrag: Ist (kWh/kWp);
            $r[0] = sprintf( "%.2f kWh/kWp", $ertrag/1.7);
            // Ertrag: Soll (kWh/kWp)
            $r[1] = sprintf( "%.2f kWh/kWp", yearTarget($y, $m, $d)/1.7);
            // Abw. zu Soll (kWh/kWp)
            $r[2] = sprintf( "%.2f kWh/kWp", $r[0]-$r[1]);
            // Abw. zu Soll (Ratio)
            $r[3] = sprintf( "%.2f %%", 100-($r[0]*100/$r[1]));
            // Ertrag: (kWh)
            $r[4] = sprintf( "%.2f kWh", $ertrag);
            // Ertrag: (Datum)
            $r[5] = sprintf( "%02d.%02d.%d", $d, $m, $y  );

            // Jahresmaximum ermitteln
            $sql = "SELECT timestamp, value
                    FROM stats 
                    WHERE name = 'month_max'
                      AND timestamp >= ".$ts_from."	
                      AND timestamp < ".$ts_to."
                    ORDER BY value DESC
                    LIMIT 1";
            
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    if ($row['value'] > $d_maximum ) {
                        // Maximum: (W)
                        $r[6] = sprintf( "%d W", $row['value'] );
                        // Maximum: (Datum)
                        $r[7] = sprintf( "%s", date( 'd.m.Y', $row['timestamp']/1000 ) );
                    }
                    else {
                        // Maximum: (W)
                        $r[6] = sprintf( "%d W", $d_maximum );
                        // Maximum: (Datum)
                        $r[7] = sprintf( "%02d.%02d.%d", $d, $m, $y );
                    }
                }
                $result->free();
            }

            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        $to_evu = 0;
        // create database object (volkszaehler)
        $mysqli = @new mysqli(DB_VZ_SERVER, DB_VZ_USER, DB_VZ_PWD, DB_VZ_NAME);
        if ($mysqli->connect_errno == 0) {
            $to_evu_1 = 0;
            $to_evu_2 = 0;

            // start wert
            if( $y > 2015 ) {
                $sql = "SELECT value
                        FROM data 
                        WHERE channel_id = 17
                          AND timestamp >= ".$ts_from."	
                        ORDER by timestamp ASC
                        LIMIT 1";
                
                if ($result = $mysqli->query($sql)) { 
                    if ($row = $result->fetch_assoc()) {
                        $to_evu_1 = $row['value'];
                   }
                    $result->free();
                }
            }
            
            // end wert
            if( $y < date('Y') ) {
                $sql = "SELECT value
                        FROM data 
                        WHERE channel_id = 17
                          AND timestamp >= ".$ts_to."
                        ORDER by timestamp ASC
                        LIMIT 1";
            } else {
                $sql = "SELECT value
                        FROM data 
                        WHERE channel_id = 17
                          AND timestamp < ".$ts_to."
                        ORDER by timestamp DESC
                        LIMIT 1";
            }
                
            if ($result = $mysqli->query($sql)) { 
                if ($row = $result->fetch_assoc()) {
                    $to_evu_2 = $row['value'];
               }
                $result->free();
            }
 
            $to_evu = $to_evu_2 - $to_evu_1;            
            
            // close connection
            $mysqli->close();
        }     
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }
                
        // Durchschnitt (Ist)
        $r[8] = sprintf( "%.2f kWh/kWp", ($r[0] / $m) );
        // Durchschnitt (Soll)
        $r[9] = sprintf( "%.2f kWh/kWp", ($r[1] / $m) );
        // Vergütung: kWh
        $r[10] = sprintf( "%.2f kWh", $to_evu );
        // Vergütung: €
        $r[11] = sprintf( "%.2f €", $to_evu * feedCompensation($y, $m, 1) );
         
        return $r;
    }

    function getMonthChartValues( $y, $m )
    {
        $r = array ();

        $days_in_month = cal_days_in_month(CAL_GREGORIAN,$m,$y);
        
        // create database object
        $mysqli = @new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_INVERTER);

        // check if connection is established
        if ($mysqli->connect_errno == 0) {
            for( $i=1; $i<=$days_in_month; $i++ ) {
                $r[$i] = sprintf( "%.3f", 0);

                $ts_from = (mktime(0,0,0,$m,$i,$y,0)*1000);
                $ts_to = $ts_from + (24*60*60*1000) - 1;

                $sql = "SELECT MAX(value) as value
                        FROM data 
                        WHERE channel = 28 
                          AND timestamp >= ".$ts_from." 
                          AND timestamp < ".$ts_to;
                          
                if ($result = $mysqli->query($sql)) { 
                    if ($row = $result->fetch_assoc()) {
                        $r[$i] = sprintf( "%.3f", $row['value']);
                    }
                    
                    $result->free();
                }
            }

            // close connection
            $mysqli->close();
        }
        else {
            // error: connecting to database
            echo "MYSQL (<strong>".$mysqli->connect_errno."</strong>): ".$mysqli->connect_error;
        }

        return $r;
    }

    function getSensorSettings( $sensorID=0 )
    {
        $mpChartType = 'areaspline';
        $mpLineType = 'solid';
        $mpName = 'Helligkeit';
        $mpDescription = 'Beschreibung';
        $mpLineColor = '000000';
        return array($mpChartType, $mpLineType, $mpName, $mpDescription, $mpLineColor);
    }

 ?>