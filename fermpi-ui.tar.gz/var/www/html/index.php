<?php
    require_once('includes/config.inc.php');
    require_once('includes/functions.inc.php');

    $timestamp = strtotime(date("Y-m-d 06:00:00"));

    $action = isset($_GET["action"]) ? $_GET["action"] : "";
    $action = isset($_POST["action"]) ? $_POST["action"] : $action;

    switch ($action) {
        case "today":
            $timestamp = strtotime(date("Y-m-d 06:00:00"));
            break;

        default:
            // do nothing
    }

    $day   = date("d", $timestamp);
    $month = date("m", $timestamp);
    $year  = date("Y", $timestamp);
        
    $content = isset($_GET["content"]) ? $_GET["content"] : "main";

    switch ($content) {
        case "maintenance":
        case "logs":
            $self = $_SERVER['PHP_SELF'].'?content='.$content;
            break;
        case "main":
            break;
        default:
            $content = "404";
    }

    if (!file_exists('pages/'.$content.'.php')) {
        $content = "404";
    }
?>

<!doctype html>
<html lang="de">
  <head>
    <meta charset="<?php echo $site_charset; ?>" />

    <!-- Always force latest IE rendering engine or request Chrome Frame -->
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Use title if it's in the page YAML frontmatter -->
    <title><?php echo $site_title; ?></title>

    <meta name="description" content="Raspberry Pi - FermPi" />
    <meta name="keywords" content="raspberry, kupke, fermpi" />

    <link rel="stylesheet" type="text/css" href="stylesheets/design.css" />

    <script src="js/jquery-2.1.4.js"></script>

    <!-- Favicon-->
    <link rel="shortcut icon" type="image/png" href="./images/favicon.png">
  </head>
  <body>
    <div id="wrapper">
        <div id="header">
            <div id="header_container">
                <div id="header-icon">
                    <a href="/index.php?content=main"><img src="./images/rpi_logo.svg" height="52" width="50"></a>
                </div>
                <div id="header-title">
                    <h1>FermPi</h1>
                </div>
                <div id="header-menu">
                    <nav class="top-bar">
                        <section class="top-bar-section">
                            <ul>
                                <li><a target="_blank" style="text-decoration:none;" href="http://homenet/phpmyadmin"><h2>phpMyAdmin</h2></a></li>
                                <li><a target="_blank" style="text-decoration:none;" href="http://fermpi:8888/status.html"><h2>RPi-Monitor</h2></a></li>
                            </ul>
                        </section>
                    </nav>
                </div>
            </div>
        </div>
        <div id="content">
			<div id="content_container">
				<div id="navigation">
					<div id="navbox">
						<div class="vmenu">
							<h1>Fermentierung</h1>
							<li><a href="/index.php?content=main">Übersicht</a></li>
							<li><a href="/index.php?content=logs">Logbuch</a></li>
							<li><a href="/index.php?content=maintenance">Einstellungen</a></li>
						</div>
					</div>
				</div>
				<div id="subject">
<?php require_once('pages/'.$content.'.php'); ?>
				</div>
			</div>
        </div>
        <div id="footer">
            <div id="footer_container">
				<div id="footer-left">
					<a target="_blank" href="http://freedns.afraid.org/">Free DNS</a>
				</div>
				<div id="footer-right">
					<a href="mailto:hokup@gmx.de">Copyright &copy; 2018, Holger Kupke</a>
				</div>
            </div>
        </div>
    </div>
</body>
 </html>
 
